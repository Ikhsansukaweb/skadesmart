"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Store,
  Home,
  MessageCircle,
  User,
  PackageSearch,
  LogOut,
  ShieldCheck,
  Headset,
  ShoppingCart,
  LayoutDashboard,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";

const BASE_NAV = [
  { href: "/home", label: "Beranda", icon: Home },
  { href: "/marketplace", label: "Marketplace", icon: Store },
  { href: "/orders/status", label: "Pesanan", icon: PackageSearch },
  { href: "/chat", label: "Chat", icon: MessageCircle },
  { href: "/account", label: "Akun", icon: User },
];

// Dashboard KWU terpisah per unit. CS & Admin punya dashboard sendiri juga.
// Item ke-6 ini muncul dinamis di bottom nav mobile sesuai role, supaya staf
// KWU/CS/Admin tidak perlu buka menu desktop untuk akses dashboard mereka.
const ROLE_EXTRA: Record<string, { href: string; label: string; icon: any }> = {
  kwu_brital: { href: "/dashboard/brital", label: "Dashboard", icon: LayoutDashboard },
  kwu_laundry: { href: "/dashboard/laundry", label: "Dashboard", icon: LayoutDashboard },
  cs: { href: "/cs", label: "CS", icon: Headset },
  admin: { href: "/admin", label: "Admin", icon: ShieldCheck },
};

export default function Navbar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const { count, open: openCart } = useCart();

  if (!user) return null;

  const extra = ROLE_EXTRA[user.role];
  const mobileNav = extra ? [...BASE_NAV, extra] : BASE_NAV;

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-brand-100">
        <div className="max-w-5xl mx-auto flex items-center justify-between px-4 py-3">
          <Link href="/home" className="font-heading text-xl text-brand-700 tracking-tight">
            SkadesMart
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {BASE_NAV.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl font-sub text-sm transition-colors ${
                  pathname === href ? "bg-brand-600 text-white" : "text-brand-700 hover:bg-brand-100"
                }`}
              >
                <Icon size={16} aria-hidden="true" />
                {label}
              </Link>
            ))}
            {extra && (
              <Link
                href={extra.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-xl font-sub text-sm transition-colors ${
                  pathname.startsWith(extra.href) ? "bg-brand-600 text-white" : "text-brand-700 hover:bg-brand-100"
                }`}
              >
                <extra.icon size={16} aria-hidden="true" />
                {extra.label}
              </Link>
            )}
          </nav>
          <div className="flex items-center gap-2">
            {count > 0 && (
              <button onClick={openCart} className="relative p-2 text-brand-700 hover:bg-brand-100 rounded-xl" aria-label="Keranjang">
                <ShoppingCart size={20} aria-hidden="true" />
                <span className="absolute -top-1 -right-1 bg-brand-600 text-white text-[10px] font-sub w-4 h-4 rounded-full flex items-center justify-center">
                  {count > 9 ? "9+" : count}
                </span>
              </button>
            )}
            <button onClick={logout} className="btn-secondary flex items-center gap-2 text-sm">
              <LogOut size={16} aria-hidden="true" />
              <span className="hidden sm:inline">Keluar</span>
            </button>
          </div>
        </div>
      </header>

      {/* Bottom nav mobile - item ke-6 dinamis (Dashboard/CS/Admin) sesuai role. */}
      <nav className="fixed bottom-0 inset-x-0 z-30 md:hidden bg-white border-t border-brand-100 flex justify-around py-2">
        {mobileNav.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex flex-col items-center gap-0.5 px-2 py-1 text-xs font-sub ${
              pathname.startsWith(href) ? "text-brand-700" : "text-slate-400"
            }`}
          >
            <Icon size={20} aria-hidden="true" />
            {label}
          </Link>
        ))}
      </nav>
    </>
  );
}
