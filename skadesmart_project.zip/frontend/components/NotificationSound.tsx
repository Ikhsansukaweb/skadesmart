"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import { collection, doc, onSnapshot, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { playNotificationSound, primeNotificationSound } from "@/lib/sound";

/**
 * Komponen tak terlihat, dipasang sekali di root layout. Mendengarkan 3
 * sinyal realtime dan memutar suara notifikasi kalau relevan:
 *
 *  1. Pesan chat baru masuk, TAPI user sedang tidak berada di halaman detail
 *     chat itu (kalau sedang di dalamnya, cukup bubble baru muncul, tak perlu
 *     suara).
 *  2. Staf KWU Brital: ada pesanan baru masuk ke dashboardnya.
 *  3. Siswa: staf KWU Laundry baru saja membuat pesanan laundry atas namanya.
 *
 * Snapshot PERTAMA dari tiap listener selalu diabaikan (tidak memutar suara),
 * supaya data lama yang sudah ada saat halaman dimuat tidak dianggap "baru".
 */
export default function NotificationSound() {
  const { user, firebaseReady } = useAuth();
  const pathname = usePathname();
  const pathnameRef = useRef(pathname);
  pathnameRef.current = pathname;

  useEffect(() => {
    primeNotificationSound();
  }, []);

  // 1) Pesan chat baru.
  useEffect(() => {
    if (!user || !firebaseReady) return;
    const seenAt = new Map<string, number>();
    let firstSnapshot = true;

    const q = query(collection(db, "chats"), where("participants", "array-contains", String(user.id)));
    const unsub = onSnapshot(q, (snap) => {
      if (firstSnapshot) {
        snap.docs.forEach((d) => {
          const data = d.data() as any;
          const millis = data.lastMessageAt?.toMillis ? data.lastMessageAt.toMillis() : 0;
          seenAt.set(d.id, millis);
        });
        firstSnapshot = false;
        return;
      }

      snap.docs.forEach((d) => {
        const data = d.data() as any;
        const millis = data.lastMessageAt?.toMillis ? data.lastMessageAt.toMillis() : 0;
        const prev = seenAt.get(d.id) || 0;
        const isNewMessage = millis > prev && data.lastSenderId !== String(user.id);
        // Halaman Chat List (/chat, bukan /chat/[id]) punya listener sendiri
        // yang MEMANG bertugas memutar suara (lihat app/chat/page.tsx) supaya
        // lebih pasti jalan - jadi di sini kita diamkan biar tidak dobel bunyi.
        const isViewingThisChat = pathnameRef.current === `/chat/${d.id}` || pathnameRef.current === "/chat";
        if (isNewMessage && !isViewingThisChat) {
          playNotificationSound();
        }
        seenAt.set(d.id, millis);
      });
    });
    return () => unsub();
  }, [user, firebaseReady]);

  // 2) Pesanan baru masuk ke dashboard KWU Brital.
  useEffect(() => {
    if (!user || !firebaseReady || user.role !== "kwu_brital") return;
    let firstSnapshot = true;

    const unsub = onSnapshot(doc(db, "seller_orders", String(user.id)), (snap) => {
      if (firstSnapshot) {
        firstSnapshot = false;
        return;
      }
      if (snap.exists()) playNotificationSound();
    });
    return () => unsub();
  }, [user, firebaseReady]);

  // 3) Pesanan laundry baru dibuat staf atas nama siswa ini.
  useEffect(() => {
    if (!user || !firebaseReady) return;
    let firstSnapshot = true;
    const knownIds = new Set<string>();

    const q = query(collection(db, "orders_status"), where("buyerId", "==", String(user.id)));
    const unsub = onSnapshot(q, (snap) => {
      if (firstSnapshot) {
        snap.docs.forEach((d) => knownIds.add(d.id));
        firstSnapshot = false;
        return;
      }
      snap.docChanges().forEach((change) => {
        if (change.type === "added" && !knownIds.has(change.doc.id)) {
          const data = change.doc.data() as any;
          if (data.kwuUnit === "kwu_laundry") playNotificationSound();
          knownIds.add(change.doc.id);
        }
      });
    });
    return () => unsub();
  }, [user, firebaseReady]);

  return null;
}
