import Link from "next/link";
import { MessageCircle, Send, Headset, Instagram, Music2 } from "lucide-react";

// Link kontak & sosial media masih placeholder (#) sampai akun resminya siap -
// tinggal ganti href di sini kalau sudah ada.
export default function Footer() {
  return (
    <footer className="mt-10 border-t border-brand-100 bg-white pb-20 md:pb-0">
      <div className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-1 sm:grid-cols-3 gap-8 text-sm">
        <div>
          <h3 className="font-heading text-lg text-brand-700 mb-2">SkadesMart</h3>
          <p className="text-slate-500 font-body">
            Marketplace internal SMKN 1 Depok Sleman untuk unit KWU (Ayam Geprek Brital, Laundry)
            dan jualan bebas antar siswa.
          </p>
        </div>

        <div>
          <h4 className="font-sub font-medium text-slate-700 mb-2">Kontak</h4>
          <ul className="space-y-1.5 text-slate-500 font-body">
            <li>
              <Link href="#" className="flex items-center gap-2 hover:text-brand-600">
                <MessageCircle size={14} aria-hidden="true" /> WhatsApp
              </Link>
            </li>
            <li>
              <Link href="#" className="flex items-center gap-2 hover:text-brand-600">
                <Send size={14} aria-hidden="true" /> Telegram
              </Link>
            </li>
            <li>
              <Link href="/cs/chat" className="flex items-center gap-2 hover:text-brand-600">
                <Headset size={14} aria-hidden="true" /> Customer Service
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-sub font-medium text-slate-700 mb-2">Media Sosial</h4>
          <div className="flex gap-3">
            <Link href="#" aria-label="Instagram" className="w-9 h-9 rounded-xl bg-brand-50 flex items-center justify-center text-brand-600 hover:bg-brand-100">
              <Instagram size={18} aria-hidden="true" />
            </Link>
            <Link href="#" aria-label="TikTok" className="w-9 h-9 rounded-xl bg-brand-50 flex items-center justify-center text-brand-600 hover:bg-brand-100">
              <Music2 size={18} aria-hidden="true" />
            </Link>
          </div>
          <Link href="#" className="block mt-4 text-slate-400 hover:text-brand-600 font-body text-xs">
            Kebijakan Privasi
          </Link>
        </div>
      </div>

      <div className="border-t border-brand-100 py-4 text-center text-xs text-slate-400 font-body">
        Made by YTTA Team
      </div>
    </footer>
  );
}
