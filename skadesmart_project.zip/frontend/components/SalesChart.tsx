"use client";

interface DayStat {
  day: string; // ISO date yyyy-mm-dd
  count: number;
  revenue: number;
}

const DAY_LABEL = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

// Chart batang sederhana tanpa dependency tambahan - jumlah pesanan selesai
// per hari (7 hari terakhir). Dipakai di dashboard KWU Brital & Laundry.
export default function SalesChart({ days }: { days: DayStat[] }) {
  const max = Math.max(1, ...days.map((d) => d.count));

  return (
    <div className="card p-4">
      <h3 className="font-sub font-medium text-sm text-slate-600 mb-3">Pesanan selesai - 7 hari terakhir</h3>
      <div className="flex items-end justify-between gap-2 h-32">
        {days.map((d) => {
          const date = new Date(d.day + "T00:00:00");
          const label = DAY_LABEL[date.getDay()];
          const heightPct = (d.count / max) * 100;
          return (
            <div key={d.day} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-xs font-sub text-brand-700">{d.count}</span>
              <div className="w-full bg-brand-50 rounded-t-lg flex items-end h-24">
                <div
                  className="w-full bg-brand-500 rounded-t-lg transition-all"
                  style={{ height: `${d.count > 0 ? Math.max(heightPct, 8) : 0}%` }}
                />
              </div>
              <span className="text-[10px] text-slate-400 font-body">{label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
