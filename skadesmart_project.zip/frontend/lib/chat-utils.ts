import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "./firebase";
import { api } from "./api";

/**
 * Dipakai penjual (KWU Brital/Laundry/siswa) di halaman Riwayat untuk
 * "melempar" kartu permintaan rating ke chat pembeli setelah pesanan selesai.
 * Chat dibuat otomatis kalau belum ada.
 */
export async function sendRatingRequest(senderId: number, buyerId: number, orderId: number): Promise<void> {
  const { chat } = await api<{ chat: { id: string } }>("/chats", {
    method: "POST",
    json: { seller_id: buyerId },
  });

  const text = "Pesananmu sudah selesai! Yuk beri rating & ulasan.";

  await addDoc(collection(db, "chats", chat.id, "messages"), {
    senderId: String(senderId),
    type: "rating_request",
    orderId,
    text,
    createdAt: serverTimestamp(),
  });

  await api("/chats/notify", { method: "POST", json: { chat_id: chat.id, text } }).catch(() => {});
}
