"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  ReactNode,
} from "react";
import { useRouter } from "next/navigation";
import { signInWithCustomToken, onAuthStateChanged, signOut as fbSignOut } from "firebase/auth";
import { auth, getMessagingIfSupported } from "./firebase";
import { getToken, onMessage } from "firebase/messaging";
import { api } from "./api";

export type Role = "siswa" | "kwu_brital" | "kwu_laundry" | "cs" | "admin";

export interface AppUser {
  id: number;
  nisn: string;
  full_name: string;
  class_name: string;
  role: Role;
  profile_photo_url?: string | null;
}

interface AuthContextValue {
  user: AppUser | null;
  loading: boolean;
  firebaseReady: boolean;
  login: (nisn: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  registerPushToken: () => Promise<{ ok: boolean; reason?: string }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  // firebaseReady = auth.currentUser sudah terisi (baik dari sesi tersimpan
  // atau dari re-auth manual di bawah). Halaman lain yang subscribe ke
  // Firestore (chat, status pesanan) menunggu flag ini true dulu supaya
  // tidak kena permission-denied gara-gara auth.uid masih null.
  const [firebaseReady, setFirebaseReady] = useState(false);
  const router = useRouter();

  // Pastikan sesi Firebase Auth sinkron dengan sesi app (cookie JWT).
  // Dipanggil setiap kali /auth/me sukses - bukan cuma sekali pas login -
  // supaya refresh halaman tidak meninggalkan Firestore dalam kondisi
  // "belum login" walau app-nya sendiri sudah login.
  const ensureFirebaseAuth = useCallback(async (appUserId: number) => {
    if (auth.currentUser && auth.currentUser.uid === String(appUserId)) {
      setFirebaseReady(true);
      return;
    }
    try {
      const data = await api<{ firebaseToken: string }>("/auth/firebase-token");
      await signInWithCustomToken(auth, data.firebaseToken);
    } catch (err) {
      console.warn("Gagal re-authenticate ke Firebase:", err);
    } finally {
      setFirebaseReady(true);
    }
  }, []);

  const refresh = useCallback(async () => {
    try {
      const data = await api<{ user: AppUser }>("/auth/me");
      setUser(data.user);
      await ensureFirebaseAuth(data.user.id);
    } catch {
      setUser(null);
      setFirebaseReady(true);
    } finally {
      setLoading(false);
    }
  }, [ensureFirebaseAuth]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Jaga-jaga: kalau Firebase mengganti/menghapus sesi di belakang layar
  // (token expired, dsb) sementara app masih menganggap user login, coba
  // re-auth sekali lagi supaya Firestore tidak diam-diam berhenti bekerja.
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (fbUser) => {
      if (user && (!fbUser || fbUser.uid !== String(user.id))) {
        ensureFirebaseAuth(user.id);
      }
    });
    return () => unsub();
  }, [user, ensureFirebaseAuth]);

  const registerPushToken = useCallback(async (): Promise<{ ok: boolean; reason?: string }> => {
    try {
      if (typeof window === "undefined" || !("Notification" in window)) {
        return { ok: false, reason: "Browser ini tidak punya Notification API." };
      }
      if (!("serviceWorker" in navigator)) {
        return { ok: false, reason: "Browser tidak mendukung Service Worker." };
      }
      const messaging = await getMessagingIfSupported();
      if (!messaging) {
        return {
          ok: false,
          reason:
            "Firebase Messaging tidak didukung di konteks ini. Penyebab paling umum: situs belum diakses lewat HTTPS (wajib, kecuali localhost).",
        };
      }

      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        return { ok: false, reason: "Izin notifikasi ditolak." };
      }

      const registration = await navigator.serviceWorker.register("/firebase-messaging-sw.js");
      await navigator.serviceWorker.ready;

      const token = await getToken(messaging, {
        vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAPID_KEY,
        serviceWorkerRegistration: registration,
      });

      if (!token) return { ok: false, reason: "Gagal mendapatkan token notifikasi dari browser." };

      await api("/auth/fcm-token", { method: "POST", json: { fcm_token: token } });
      console.log("[FCM] Token notifikasi berhasil didaftarkan ke server.");

      onMessage(messaging, (payload) => {
        console.log("Notifikasi diterima di foreground:", payload);
      });

      return { ok: true };
    } catch (err: any) {
      console.warn("Gagal mendaftarkan token notifikasi:", err);
      return { ok: false, reason: err?.message || "Terjadi kesalahan saat mendaftarkan notifikasi." };
    }
  }, []);

  const login = useCallback(async (nisn: string, password: string) => {
    const data = await api<{ user: AppUser; firebaseToken: string | null }>("/auth/login", {
      method: "POST",
      json: { nisn, password },
    });
    setUser(data.user);

    if (data.firebaseToken) {
      await signInWithCustomToken(auth, data.firebaseToken);
    }
    setFirebaseReady(true);
    // Fire-and-forget, tapi TETAP di-log ke console kalau gagal - sebelumnya
    // hasil pemanggilan ini dibuang begitu saja tanpa jejak apa pun, jadi
    // kegagalan (browser tidak support, belum HTTPS, dsb) tidak pernah
    // terlihat di console sama sekali.
    registerPushToken().then((result) => {
      if (!result.ok) console.warn("[FCM] Notifikasi tidak aktif otomatis saat login:", result.reason);
    });
    router.push("/home");
  }, [router, registerPushToken]);

  const logout = useCallback(async () => {
    await api("/auth/logout", { method: "POST" });
    await fbSignOut(auth).catch(() => {});
    setUser(null);
    setFirebaseReady(false);
    router.push("/login");
  }, [router]);

  return (
    <AuthContext.Provider value={{ user, loading, firebaseReady, login, logout, refresh, registerPushToken }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth harus dipakai di dalam AuthProvider");
  return ctx;
}
