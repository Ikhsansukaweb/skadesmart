const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api";

interface ApiOptions extends RequestInit {
  json?: unknown;
}

/**
 * Wrapper fetch ke backend Express. Selalu credentials: 'include' supaya
 * httpOnly cookie JWT ikut terkirim di setiap request.
 */
export async function api<T = any>(path: string, options: ApiOptions = {}): Promise<T> {
  const { json, headers, ...rest } = options;

  const res = await fetch(`${API_URL}${path}`, {
    credentials: "include",
    headers: {
      ...(json ? { "Content-Type": "application/json" } : {}),
      ...headers,
    },
    body: json ? JSON.stringify(json) : options.body,
    ...rest,
  });

  const contentType = res.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await res.json() : null;

  if (!res.ok) {
    const err = new Error(data?.error || `Permintaan gagal (${res.status})`) as Error & { code?: string; status?: number };
    if (data?.code) err.code = data.code;
    err.status = res.status;
    throw err;
  }
  return data as T;
}

export async function uploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${API_URL}/upload/image`, {
    method: "POST",
    credentials: "include",
    body: form,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || "Upload gambar gagal.");
  return data.url as string;
}

// Upload banyak foto sekaligus (galeri produk / jualan siswa, 2-8 foto).
export async function uploadImages(files: File[]): Promise<string[]> {
  const form = new FormData();
  files.forEach((f) => form.append("files", f));

  const res = await fetch(`${API_URL}/upload/images`, {
    method: "POST",
    credentials: "include",
    body: form,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || "Upload gambar gagal.");
  return data.urls as string[];
}
