import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Skema biru muda & putih - bersih, ringan, friendly untuk siswa SMK (bagian 7).
        brand: {
          50: "#f0f9ff",
          100: "#e0f2fe",
          200: "#bae6fd",
          300: "#7dd3fc",
          400: "#38bdf8",
          500: "#0ea5e9",
          600: "#0284c7",
          700: "#0369a1",
        },
      },
      fontFamily: {
        heading: ["var(--font-oswald)", "sans-serif"],
        sub: ["var(--font-saira)", "sans-serif"],
        body: ["var(--font-smooch)", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
