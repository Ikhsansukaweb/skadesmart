/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Foto produk/profil di-upload ke Catbox, izinkan domain hostingnya.
    remotePatterns: [
      { protocol: "https", hostname: "files.catbox.moe" },
    ],
  },
};

module.exports = nextConfig;
