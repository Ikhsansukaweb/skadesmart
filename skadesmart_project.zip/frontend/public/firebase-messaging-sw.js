// Service worker untuk menerima push notification (FCM Web) saat tab
// browser tidak aktif / di background. Diletakkan di root public/ supaya
// scope-nya mencakup seluruh origin.
importScripts("https://www.gstatic.com/firebasejs/10.12.5/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.12.5/firebase-messaging-compat.js");

// NOTE: config ini sama dengan NEXT_PUBLIC_FIREBASE_* di .env.local.
// Service worker tidak bisa membaca env Next.js, jadi nilainya ditulis manual
// di sini. Update manual kalau config Firebase project berubah.
firebase.initializeApp({
  apiKey: "AIzaSyD6ifeTULUG0yQbxIqTLcuXHb9MMGYXWfk",
  authDomain: "skadesmart.firebaseapp.com",
  projectId: "skadesmart",
  storageBucket: "skadesmart.firebasestorage.app",
  messagingSenderId: "154888780324",
  appId: "1:154888780324:web:5f39121390298bb1f3f6b1",
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const { title, body } = payload.notification || {};
  const link = payload.data?.link || "/";

  self.registration.showNotification(title || "SkadesMart", {
    body: body || "",
    icon: "/icon-192.png",
    data: { link },
  });
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const link = event.notification.data?.link || "/";
  event.waitUntil(clients.openWindow(link));
});
