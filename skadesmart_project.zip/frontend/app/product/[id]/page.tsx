"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import {
  MessageCircle,
  ShoppingCart,
  PackageX,
  LoaderCircle,
  ChevronLeft,
  ChevronRight,
  ShoppingBasket,
  UserRound,
  Lock,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import RatingStars from "@/components/RatingStars";
import { api } from "@/lib/api";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";

interface ProductDetail {
  id: number;
  seller_id: number;
  seller_name: string;
  seller_class: string;
  seller_photo: string | null;
  seller_shop_open: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  images: string[];
  category: "kwu_brital" | "siswa";
}

interface RatingItem {
  score: number;
  comment: string;
  buyer_name: string;
  created_at: string;
}

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const { refresh: refreshCart, open: openCart } = useCart();

  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [ratings, setRatings] = useState<RatingItem[]>([]);
  const [avgRating, setAvgRating] = useState(0);
  const [imgIndex, setImgIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<"direct" | "cart" | "contact" | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    api<{ product: ProductDetail; ratings: RatingItem[] }>(`/products/${id}`)
      .then((d) => {
        setProduct(d.product);
        setRatings(d.ratings);
        if (d.ratings.length) {
          setAvgRating(d.ratings.reduce((a, r) => a + r.score, 0) / d.ratings.length);
        }
      })
      .catch(() => setProduct(null));
  }, [id]);

  async function getOrCreateChat() {
    if (!product) return null;
    const data = await api<{ chat: { id: string } }>("/chats", {
      method: "POST",
      json: { seller_id: product.seller_id, product_id: product.id },
    });
    return data.chat.id;
  }

  async function handleChat() {
    const chatId = await getOrCreateChat();
    if (chatId) router.push(`/chat/${chatId}`);
  }

  // "Hubungi untuk Pesan" (jualan siswa): buka chat lalu langsung kirim
  // template pesan + foto produk, seperti share produk di WhatsApp.
  async function handleContactToOrder() {
    if (!product || !user) return;
    setBusy("contact");
    setError("");
    try {
      const chatId = await getOrCreateChat();
      if (!chatId) return;

      await addDoc(collection(db, "chats", chatId, "messages"), {
        senderId: String(user.id),
        text: "Halo, apakah barang ini masih ada?",
        imageUrl: product.images[0] || undefined,
        createdAt: serverTimestamp(),
      });
      api("/chats/notify", {
        method: "POST",
        json: { chat_id: chatId, text: "Halo, apakah barang ini masih ada?" },
      }).catch(() => {});

      router.push(`/chat/${chatId}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(null);
    }
  }

  async function handleAddToCart() {
    if (!product) return;
    setBusy("cart");
    setError("");
    setMessage("");
    try {
      await api("/cart", { method: "POST", json: { product_id: product.id, quantity, note: note || undefined } });
      refreshCart();
      setMessage("Ditambahkan ke keranjang.");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(null);
    }
  }

  async function handleDirectOrder() {
    if (!product) return;
    setBusy("direct");
    setError("");
    try {
      await api("/orders/brital/direct", {
        method: "POST",
        json: { product_id: product.id, quantity, note: note || undefined },
      });
      router.push("/orders/status");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(null);
    }
  }

  if (!product) {
    return (
      <main className="min-h-screen">
        <Navbar />
        <p className="text-center py-10 text-slate-400 font-body">Memuat produk...</p>
      </main>
    );
  }

  const isOwnProduct = user?.id === product.seller_id;
  const images = product.images.length ? product.images : [];
  const isClosed = product.category === "kwu_brital" && !product.seller_shop_open;

  return (
    <main className="min-h-screen pb-24 md:pb-8">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-6 grid md:grid-cols-2 gap-6">
        <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-brand-100">
          {images.length > 0 ? (
            <>
              <Image src={images[imgIndex]} alt={product.name} fill className="object-cover" priority />
              {images.length > 1 && (
                <>
                  <button onClick={() => setImgIndex((i) => (i - 1 + images.length) % images.length)} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1.5" aria-label="Foto sebelumnya">
                    <ChevronLeft size={18} aria-hidden="true" />
                  </button>
                  <button onClick={() => setImgIndex((i) => (i + 1) % images.length)} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1.5" aria-label="Foto selanjutnya">
                    <ChevronRight size={18} aria-hidden="true" />
                  </button>
                  <div className="absolute bottom-2 inset-x-0 flex justify-center gap-1">
                    {images.map((_, i) => (
                      <span key={i} className={`w-1.5 h-1.5 rounded-full ${i === imgIndex ? "bg-white" : "bg-white/50"}`} />
                    ))}
                  </div>
                </>
              )}
              {isClosed && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center gap-2 text-white font-sub">
                  <Lock size={18} aria-hidden="true" /> Toko sedang tutup
                </div>
              )}
            </>
          ) : (
            <div className="w-full h-full flex items-center justify-center text-brand-300">
              <PackageX size={48} aria-hidden="true" />
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div>
            <h1 className="text-2xl">{product.name}</h1>
            <Link href={`/profile/${product.seller_id}`} className="inline-flex items-center gap-2 text-sm text-slate-500 font-body hover:text-brand-600">
              {product.seller_photo ? (
                <Image src={product.seller_photo} alt={product.seller_name} width={20} height={20} className="rounded-full object-cover" />
              ) : (
                <UserRound size={16} aria-hidden="true" />
              )}
              {product.seller_name}{product.category === "siswa" ? ` - ${product.seller_class}` : ""}
            </Link>
          </div>

          <RatingStars value={avgRating} count={ratings.length} />

          <p className="text-2xl text-brand-700 font-heading">Rp{product.price.toLocaleString("id-ID")}</p>
          <p className="text-sm font-body text-slate-600 whitespace-pre-line">{product.description}</p>
          <p className="text-sm font-sub text-slate-500">Stok: {product.stock}</p>

          {error && <p role="alert" className="text-sm text-red-600 font-body">{error}</p>}
          {message && <p className="text-sm text-brand-600 font-body">{message}</p>}

          {!isOwnProduct && (
            <div className="space-y-3">
              {product.category !== "siswa" && (
                <>
                  <div className="flex items-center gap-3">
                    <label htmlFor="quantity" className="text-sm font-sub text-slate-600 shrink-0">Jumlah</label>
                    <input
                      id="quantity"
                      type="number"
                      min={1}
                      max={product.stock}
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, Number(e.target.value)))}
                      className="input-field w-24"
                      disabled={isClosed}
                    />
                  </div>
                  <div>
                    <label htmlFor="note" className="block text-sm font-sub mb-1 text-slate-600">
                      Request untuk penjual (opsional)
                    </label>
                    <textarea
                      id="note"
                      rows={2}
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="Misal: pedas level 3, tanpa sambal, dll"
                      className="input-field"
                      disabled={isClosed}
                    />
                  </div>
                </>
              )}
              <div className="flex flex-col sm:flex-row gap-3">
                {product.category === "siswa" ? (
                  <button onClick={handleContactToOrder} disabled={busy !== null} className="btn-primary flex items-center justify-center gap-2 flex-1">
                    {busy === "contact" ? <LoaderCircle size={16} className="animate-spin" aria-hidden="true" /> : <MessageCircle size={16} aria-hidden="true" />}
                    Hubungi untuk Pesan
                  </button>
                ) : (
                  <>
                    <button onClick={handleChat} className="btn-secondary flex items-center justify-center gap-2 flex-1">
                      <MessageCircle size={16} aria-hidden="true" /> Chat Penjual
                    </button>
                    <button
                      onClick={handleAddToCart}
                      disabled={busy !== null || product.stock === 0 || isClosed}
                      className="btn-secondary flex items-center justify-center gap-2 flex-1"
                    >
                      {busy === "cart" ? <LoaderCircle size={16} className="animate-spin" aria-hidden="true" /> : <ShoppingBasket size={16} aria-hidden="true" />}
                      Masukkan Keranjang
                    </button>
                    <button
                      onClick={handleDirectOrder}
                      disabled={busy !== null || product.stock === 0 || isClosed}
                      className="btn-primary flex items-center justify-center gap-2 flex-1"
                    >
                      {busy === "direct" ? <LoaderCircle size={16} className="animate-spin" aria-hidden="true" /> : <ShoppingCart size={16} aria-hidden="true" />}
                      Pesan Langsung
                    </button>
                  </>
                )}
              </div>
              {isClosed && <p className="text-xs text-red-500 font-body">Toko sedang tutup, belum bisa menerima pesanan.</p>}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 pb-8">
        <h2 className="text-xl mb-3 text-brand-700">Ulasan</h2>
        <div className="space-y-3">
          {ratings.map((r, idx) => (
            <div key={idx} className="card p-4">
              <div className="flex items-center justify-between">
                <span className="font-sub font-medium text-sm">{r.buyer_name}</span>
                <RatingStars value={r.score} size={12} />
              </div>
              {r.comment && <p className="text-sm font-body text-slate-600 mt-1">{r.comment}</p>}
            </div>
          ))}
          {ratings.length === 0 && <p className="text-slate-400 font-body text-sm">Belum ada ulasan.</p>}
        </div>
      </div>
    </main>
  );
}
