"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { ShoppingCart, KeyRound, IdCard, LoaderCircle } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export default function LoginPage() {
  const { login } = useAuth();
  const [nisn, setNisn] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notFound, setNotFound] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setNotFound(false);
    setSubmitting(true);
    try {
      await login(nisn, password);
    } catch (err: any) {
      setError(err.message || "Login gagal. Coba lagi.");
      setNotFound(err.code === "NISN_NOT_FOUND" || /belum terdaftar/i.test(err.message || ""));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm card p-6 space-y-6">
        <div className="text-center space-y-1">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-brand-100 flex items-center justify-center text-brand-600">
            <ShoppingCart size={24} aria-hidden="true" />
          </div>
          <h1 className="text-2xl text-brand-700">SkadesMart</h1>
          <p className="text-sm text-slate-500 font-body">
            Marketplace internal SMKN 1 Depok Sleman
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div>
            <label htmlFor="nisn" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <IdCard size={16} aria-hidden="true" /> NISN
            </label>
            <input
              id="nisn"
              inputMode="numeric"
              pattern="\d{5}"
              maxLength={5}
              required
              value={nisn}
              onChange={(e) => setNisn(e.target.value.replace(/\D/g, ""))}
              placeholder="5 digit angka"
              className="input-field"
              autoComplete="username"
            />
          </div>
          <div>
            <label htmlFor="password" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <KeyRound size={16} aria-hidden="true" /> Password
            </label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="input-field"
              autoComplete="current-password"
            />
          </div>

          {error && (
            <p role="alert" className="text-sm text-red-600 font-body">
              {error}{" "}
              {notFound && (
                <Link href="/register" className="underline font-sub">Daftar sekarang</Link>
              )}
            </p>
          )}

          <button type="submit" disabled={submitting} className="btn-primary w-full flex items-center justify-center gap-2">
            {submitting && <LoaderCircle size={16} className="animate-spin" aria-hidden="true" />}
            Masuk
          </button>
        </form>

        <p className="text-sm text-center text-slate-500 font-body">
          Belum punya akun? <Link href="/register" className="text-brand-600 font-sub">Daftar di sini</Link>
        </p>
      </div>
    </main>
  );
}
