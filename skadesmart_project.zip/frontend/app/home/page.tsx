"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { UtensilsCrossed, Shirt, ShoppingBag, ArrowRight, ChevronDown, MapPin } from "lucide-react";
import Navbar from "@/components/Navbar";
import ProductCard, { ProductCardData } from "@/components/ProductCard";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

interface KwuUnit {
  id: number;
  slug: string;
  name: string;
  description: string;
  how_to_order: string | null;
  price_info: string | null;
}

function ScrollSection({ title, viewAllHref, products }: { title: string; viewAllHref: string; products: ProductCardData[] }) {
  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-xl text-brand-700">{title}</h2>
        <Link href={viewAllHref} className="text-sm text-brand-600 font-sub">Lihat semua</Link>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-2 -mx-4 px-4 snap-x snap-mandatory">
        {products.map((p) => (
          <div key={p.id} className="w-40 shrink-0 snap-start">
            <ProductCard product={p} />
          </div>
        ))}
        {products.length === 0 && <p className="text-slate-400 font-body text-sm">Belum ada produk.</p>}
      </div>
    </section>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  const [units, setUnits] = useState<KwuUnit[]>([]);
  const [britalProducts, setBritalProducts] = useState<ProductCardData[]>([]);
  const [siswaProducts, setSiswaProducts] = useState<ProductCardData[]>([]);
  const [laundryOpen, setLaundryOpen] = useState(false);

  useEffect(() => {
    api<{ units: KwuUnit[] }>("/kwu").then((d) => setUnits(d.units)).catch(() => {});
    api<{ products: ProductCardData[] }>("/products?category=kwu_brital&limit=10")
      .then((d) => setBritalProducts(d.products))
      .catch(() => {});
    api<{ products: ProductCardData[] }>("/products?category=siswa&limit=10")
      .then((d) => setSiswaProducts(d.products))
      .catch(() => {});
  }, []);

  const laundry = units.find((u) => u.slug === "kwu_laundry");

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-8">
        <section className="card p-6 bg-gradient-to-br from-brand-500 to-brand-600 text-white">
          <h1 className="text-2xl md:text-3xl">Halo, {user?.full_name || "Siswa"}</h1>
          <p className="font-body opacity-90 mt-1">
            Pesan Ayam Geprek Brital atau jelajahi jualan siswa, semua dalam satu tempat.
          </p>
          <Link href="/marketplace" className="inline-flex items-center gap-2 mt-4 bg-white text-brand-700 font-sub px-4 py-2 rounded-xl">
            Ke Marketplace <ArrowRight size={16} aria-hidden="true" />
          </Link>
        </section>

        {/* Laundry TIDAK punya marketplace/listing - cuma banner info cara pesan. */}
        {laundry && (
          <section className="card overflow-hidden">
            <button
              onClick={() => setLaundryOpen((v) => !v)}
              className="w-full flex items-center justify-between gap-3 p-4 text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-brand-100 flex items-center justify-center text-brand-600 shrink-0">
                  <Shirt size={20} aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-sub font-medium">{laundry.name}</h3>
                  <p className="text-xs text-slate-500 font-body">Cara pemesanan laundry - datang langsung ke tempat</p>
                </div>
              </div>
              <ChevronDown size={18} className={`text-brand-500 transition-transform shrink-0 ${laundryOpen ? "rotate-180" : ""}`} aria-hidden="true" />
            </button>
            {laundryOpen && (
              <div className="px-4 pb-4 pt-0 space-y-3 border-t border-brand-100">
                <p className="text-sm font-body text-slate-600 whitespace-pre-line pt-3">{laundry.how_to_order}</p>
                {laundry.price_info && (
                  <div className="flex items-start gap-2 text-sm font-body text-brand-700 bg-brand-50 rounded-xl p-3">
                    <MapPin size={16} className="shrink-0 mt-0.5" aria-hidden="true" />
                    {laundry.price_info}
                  </div>
                )}
              </div>
            )}
          </section>
        )}

        <section>
          <h2 className="text-xl mb-3 text-brand-700">Unit KWU</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link href="/marketplace?category=kwu_brital" className="card p-4 flex items-center gap-3 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-brand-100 flex items-center justify-center text-brand-600 shrink-0">
                <UtensilsCrossed size={22} aria-hidden="true" />
              </div>
              <div>
                <h3 className="font-sub font-medium">Ayam Geprek Brital</h3>
                <p className="text-sm text-slate-500 font-body line-clamp-1">Pesan lewat marketplace</p>
              </div>
            </Link>
            <Link href="/marketplace?category=siswa" className="card p-4 flex items-center gap-3 hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-xl bg-brand-100 flex items-center justify-center text-brand-600 shrink-0">
                <ShoppingBag size={22} aria-hidden="true" />
              </div>
              <div>
                <h3 className="font-sub font-medium">Jualan Siswa</h3>
                <p className="text-sm text-slate-500 font-body line-clamp-1">Produk dari sesama siswa</p>
              </div>
            </Link>
          </div>
        </section>

        <ScrollSection title="Ayam Geprek Brital" viewAllHref="/marketplace?category=kwu_brital" products={britalProducts} />
        <ScrollSection title="Jualan Siswa" viewAllHref="/marketplace?category=siswa" products={siswaProducts} />
      </div>
    </main>
  );
}
