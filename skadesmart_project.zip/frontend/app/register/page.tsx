"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ShoppingCart, KeyRound, IdCard, UserRound, GraduationCap, LoaderCircle } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

export default function RegisterPage() {
  const { refresh } = useAuth();
  const router = useRouter();

  const [nisn, setNisn] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [className, setClassName] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await api("/auth/register", {
        method: "POST",
        json: { nisn, password, full_name: fullName, class_name: className },
      });
      await refresh();
      router.push("/home");
    } catch (err: any) {
      setError(err.message || "Registrasi gagal.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm card p-6 space-y-6">
        <div className="text-center space-y-1">
          <div className="mx-auto w-12 h-12 rounded-2xl bg-brand-100 flex items-center justify-center text-brand-600">
            <ShoppingCart size={24} aria-hidden="true" />
          </div>
          <h1 className="text-2xl text-brand-700">Daftar Akun</h1>
          <p className="text-sm text-slate-500 font-body">NISN belum terdaftar? Buat akun baru di sini.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          <div>
            <label htmlFor="nisn" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <IdCard size={16} aria-hidden="true" /> NISN
            </label>
            <input
              id="nisn"
              inputMode="numeric"
              maxLength={5}
              required
              value={nisn}
              onChange={(e) => setNisn(e.target.value.replace(/\D/g, ""))}
              placeholder="5 digit angka"
              className="input-field"
            />
          </div>
          <div>
            <label htmlFor="full_name" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <UserRound size={16} aria-hidden="true" /> Nama lengkap
            </label>
            <input id="full_name" required value={fullName} onChange={(e) => setFullName(e.target.value)} className="input-field" />
          </div>
          <div>
            <label htmlFor="class_name" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <GraduationCap size={16} aria-hidden="true" /> Kelas
            </label>
            <input id="class_name" required value={className} onChange={(e) => setClassName(e.target.value)} placeholder="Misal: 11RPL1" className="input-field" />
          </div>
          <div>
            <label htmlFor="password" className="flex items-center gap-2 text-sm font-sub mb-1 text-slate-600">
              <KeyRound size={16} aria-hidden="true" /> Password
            </label>
            <input id="password" type="password" required minLength={4} value={password} onChange={(e) => setPassword(e.target.value)} className="input-field" />
          </div>

          {error && <p role="alert" className="text-sm text-red-600 font-body">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full flex items-center justify-center gap-2">
            {submitting && <LoaderCircle size={16} className="animate-spin" aria-hidden="true" />}
            Daftar
          </button>
        </form>

        <p className="text-sm text-center text-slate-500 font-body">
          Sudah punya akun? <Link href="/login" className="text-brand-600 font-sub">Login di sini</Link>
        </p>
      </div>
    </main>
  );
}
