"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { UtensilsCrossed, PackageSearch, History, PackagePlus, Store } from "lucide-react";
import Navbar from "@/components/Navbar";
import SalesChart from "@/components/SalesChart";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

interface DayStat { day: string; count: number; revenue: number }

// Overview Dashboard Brital: chart penjualan 7 hari + akses cepat ke
// Pesanan Aktif, Riwayat, dan Kelola Menu (masing-masing halaman terpisah).
export default function BritalDashboardOverview() {
  const { user } = useAuth();
  const [days, setDays] = useState<DayStat[]>([]);
  const [shopOpen, setShopOpen] = useState<number | null>(null);

  useEffect(() => {
    api<{ days: DayStat[] }>("/orders/stats").then((d) => setDays(d.days)).catch(() => {});
    api<{ user: { shop_open: number } }>("/account").then((d) => setShopOpen(d.user.shop_open)).catch(() => {});
  }, []);

  async function toggleShop() {
    if (shopOpen === null) return;
    await api("/account/shop-status", { method: "PUT", json: { shop_open: !shopOpen } });
    setShopOpen(shopOpen ? 0 : 1);
  }

  if (user && user.role !== "kwu_brital" && user.role !== "admin") {
    return (
      <main className="min-h-screen">
        <Navbar />
        <p className="text-center py-10 text-slate-400 font-body">Halaman ini khusus staf KWU Brital.</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-brand-700 flex items-center gap-2">
            <UtensilsCrossed size={22} aria-hidden="true" /> Dashboard Brital
          </h1>
          {shopOpen !== null && (
            <button onClick={toggleShop} className={`text-xs font-sub px-3 py-1.5 rounded-full flex items-center gap-1.5 ${shopOpen ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
              <Store size={12} aria-hidden="true" />
              {shopOpen ? "Toko Buka" : "Toko Tutup"}
            </button>
          )}
        </div>

        <SalesChart days={days} />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Link href="/dashboard/brital/orders" className="card p-4 flex flex-col items-center gap-2 text-center hover:shadow-md transition-shadow">
            <PackageSearch size={24} className="text-brand-600" aria-hidden="true" />
            <span className="font-sub text-sm font-medium">Pesanan Aktif</span>
          </Link>
          <Link href="/dashboard/brital/history" className="card p-4 flex flex-col items-center gap-2 text-center hover:shadow-md transition-shadow">
            <History size={24} className="text-brand-600" aria-hidden="true" />
            <span className="font-sub text-sm font-medium">Riwayat</span>
          </Link>
          <Link href="/product/mine" className="card p-4 flex flex-col items-center gap-2 text-center hover:shadow-md transition-shadow">
            <PackagePlus size={24} className="text-brand-600" aria-hidden="true" />
            <span className="font-sub text-sm font-medium">Kelola Menu</span>
          </Link>
        </div>
      </div>
    </main>
  );
}
