"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, LoaderCircle, Trash2, Star } from "lucide-react";
import Navbar from "@/components/Navbar";
import StatusBadge from "@/components/StatusBadge";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { sendRatingRequest } from "@/lib/chat-utils";

interface HistoryOrder {
  id: number;
  buyer_id: number;
  buyer_name: string;
  buyer_class: string;
  weight_kg: number | null;
  total_price: number;
  status: string;
  payment_status: string;
}

const DONE_STATUSES = ["selesai", "dibatalkan"];

export default function LaundryHistoryPage() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<HistoryOrder[]>([]);
  const [busyId, setBusyId] = useState<number | null>(null);

  function load() {
    api<{ orders: HistoryOrder[] }>("/orders/incoming")
      .then((d) => setOrders(d.orders.filter((o: any) => DONE_STATUSES.includes(o.status))))
      .catch(() => {});
  }

  useEffect(load, []);

  async function handleDelete(id: number) {
    if (!confirm("Hapus riwayat pesanan ini?")) return;
    setBusyId(id);
    try {
      await api(`/orders/${id}`, { method: "DELETE" });
      load();
    } finally {
      setBusyId(null);
    }
  }

  async function handleRequestRating(order: HistoryOrder) {
    if (!user) return;
    setBusyId(order.id);
    try {
      await sendRatingRequest(user.id, order.buyer_id, order.id);
      alert("Permintaan rating terkirim ke chat pembeli.");
    } catch (err: any) {
      alert(err.message);
    } finally {
      setBusyId(null);
    }
  }

  if (user && user.role !== "kwu_laundry" && user.role !== "admin") {
    return (
      <main className="min-h-screen">
        <Navbar />
        <p className="text-center py-10 text-slate-400 font-body">Halaman ini khusus staf KWU Laundry.</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        <Link href="/dashboard/laundry" className="inline-flex items-center gap-2 text-sm text-brand-600 font-sub">
          <ArrowLeft size={16} aria-hidden="true" /> Kembali ke Dashboard
        </Link>
        <h1 className="text-2xl text-brand-700">Riwayat Pesanan</h1>

        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="card p-4 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-sub font-medium">{o.buyer_name}</h3>
                  <p className="text-sm text-slate-500 font-body">{o.buyer_class}</p>
                </div>
                <StatusBadge status={o.status} />
              </div>
              <p className="text-sm font-body text-slate-600">{o.weight_kg ? `${o.weight_kg} kg` : "-"}</p>
              <p className="font-heading text-brand-700">Rp{o.total_price.toLocaleString("id-ID")}</p>

              <div className="flex gap-2 pt-1 flex-wrap">
                {o.status === "selesai" && (
                  <button
                    onClick={() => handleRequestRating(o)}
                    disabled={busyId === o.id}
                    className="btn-secondary text-sm flex items-center gap-2"
                  >
                    {busyId === o.id ? <LoaderCircle size={14} className="animate-spin" aria-hidden="true" /> : <Star size={14} aria-hidden="true" />}
                    Minta Rating
                  </button>
                )}
                <button onClick={() => handleDelete(o.id)} disabled={busyId === o.id} className="text-sm text-red-500 flex items-center gap-2 px-3 py-2">
                  <Trash2 size={14} aria-hidden="true" /> Hapus Riwayat
                </button>
              </div>
            </div>
          ))}
          {orders.length === 0 && <p className="text-slate-400 font-body text-sm">Belum ada riwayat.</p>}
        </div>
      </div>
    </main>
  );
}
