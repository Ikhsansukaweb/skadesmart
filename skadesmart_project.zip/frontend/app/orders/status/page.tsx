"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { onSnapshot, doc } from "firebase/firestore";
import { Star } from "lucide-react";
import Navbar from "@/components/Navbar";
import StatusBadge from "@/components/StatusBadge";
import { api } from "@/lib/api";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";

interface OrderItem {
  product_id: number;
  product_name: string;
  unit_price: number;
  quantity: number;
  note: string | null;
}

interface MyOrder {
  id: number;
  kwu_unit: "kwu_brital" | "kwu_laundry";
  status: string;
  payment_status: string;
  total_price: number;
  quantity: number | null;
  weight_kg: number | null;
  seller_name: string;
  items: OrderItem[];
  created_at: string;
}

// Siswa memantau status pesanan (Brital & Laundry) secara realtime via
// onSnapshot(), tanpa perlu refresh manual.
export default function OrderStatusPage() {
  const { firebaseReady } = useAuth();
  const [orders, setOrders] = useState<MyOrder[]>([]);

  useEffect(() => {
    api<{ orders: MyOrder[] }>("/orders/mine").then((d) => setOrders(d.orders)).catch(() => {});
  }, []);

  useEffect(() => {
    if (orders.length === 0 || !firebaseReady) return;
    const unsubscribes = orders.map((o) =>
      onSnapshot(doc(db, "orders_status", String(o.id)), (snap) => {
        const data = snap.data();
        if (!data) return;
        setOrders((prev) => prev.map((p) => (p.id === o.id ? { ...p, status: data.status } : p)));
      })
    );
    return () => unsubscribes.forEach((unsub) => unsub());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orders.length, firebaseReady]);

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        <h1 className="text-2xl text-brand-700">Status Pesanan</h1>

        <div className="space-y-3">
          {orders.map((o) => (
            <div key={o.id} className="card p-4 space-y-2">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-sub font-medium text-sm">
                    {o.kwu_unit === "kwu_brital" ? "Ayam Geprek Brital" : "Laundry"} - {o.seller_name}
                  </h3>
                  <p className="text-xs text-slate-400 font-body">
                    {new Date(o.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}
                  </p>
                </div>
                <StatusBadge status={o.status} />
              </div>

              {o.kwu_unit === "kwu_brital" ? (
                <ul className="text-sm font-body text-slate-600 space-y-0.5">
                  {o.items.map((it, idx) => (
                    <li key={idx}>{it.product_name} x{it.quantity}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm font-body text-slate-600">
                  {o.quantity} potong{o.weight_kg ? ` - ${o.weight_kg} kg` : ""}
                </p>
              )}

              <div className="flex items-center justify-between pt-1">
                <span className="font-heading text-brand-700">Rp{o.total_price.toLocaleString("id-ID")}</span>
                <span className={`text-xs font-sub px-2 py-0.5 rounded-full ${o.payment_status === "sudah_bayar" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                  {o.payment_status === "sudah_bayar" ? "Sudah bayar" : "Belum bayar"}
                </span>
              </div>

              {o.status === "selesai" && (
                <Link href={`/rating/${o.id}`} className="inline-flex items-center gap-1 text-xs text-brand-600 font-sub pt-1">
                  <Star size={12} aria-hidden="true" /> Beri rating pesanan ini
                </Link>
              )}
            </div>
          ))}
          {orders.length === 0 && <p className="text-slate-400 font-body text-sm">Belum ada pesanan.</p>}
        </div>
      </div>
    </main>
  );
}
