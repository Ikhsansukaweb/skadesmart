"use client";

import { useEffect, useRef, useState, FormEvent } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {
  collection,
  addDoc,
  doc,
  updateDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
} from "firebase/firestore";
import {
  Send,
  Image as ImageIcon,
  UserRound,
  LoaderCircle,
  ArrowLeft,
  MoreVertical,
  BellOff,
  Bell,
  Trash2,
  Star,
  Bot,
  CheckCircle2,
  X,
} from "lucide-react";
import { api, uploadImage } from "@/lib/api";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { sendRatingRequest } from "@/lib/chat-utils";

interface ChatMeta {
  id: string;
  buyer_id: number;
  seller_id: number;
  cs_mode: "ai" | "human";
}

interface OtherUser {
  id: number;
  full_name: string;
  profile_photo_url: string | null;
  role: string;
}

interface ChatProduct {
  id: number;
  name: string;
  price: number;
  category: string;
  seller_id: number;
}

interface Message {
  id: string;
  senderId: string;
  text?: string;
  imageUrl?: string;
  type?: "rating_request";
  orderId?: number;
  isAi?: boolean;
  createdAt: any;
}

const SEND_COOLDOWN_MS = 2000;

// Chat Page (detail) - mirip WhatsApp: header dengan tombol kembali + menu
// titik-tiga, bubble teks/foto, kartu permintaan rating, balasan AI CS
// bertanda "Bot", dan tombol "Tandai Selesai" untuk jualan siswa.
export default function ChatDetailPage() {
  const { chatId } = useParams<{ chatId: string }>();
  const router = useRouter();
  const { user, firebaseReady } = useAuth();

  const [meta, setMeta] = useState<ChatMeta | null>(null);
  const [other, setOther] = useState<OtherUser | null>(null);
  const [product, setProduct] = useState<ChatProduct | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [sendingImage, setSendingImage] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [muted, setMuted] = useState(false);
  const [cooldown, setCooldown] = useState(false);
  const [completeModalOpen, setCompleteModalOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api<{ chat: ChatMeta; other: OtherUser; product: ChatProduct | null }>(`/chats/${chatId}`)
      .then((d) => {
        setMeta(d.chat);
        setOther(d.other);
        setProduct(d.product);
      })
      .catch(() => {});
  }, [chatId]);

  useEffect(() => {
    if (!firebaseReady) return;
    const q = query(collection(db, "chats", chatId, "messages"), orderBy("createdAt", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
    });
    return () => unsub();
  }, [chatId, firebaseReady]);

  useEffect(() => {
    if (!user || !firebaseReady || messages.length === 0) return;
    updateDoc(doc(db, "chats", chatId), { [`lastReadAt.${user.id}`]: serverTimestamp() }).catch(() => {});
  }, [user, firebaseReady, chatId, messages.length]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const isCsChat = other?.role === "cs";

  async function handleSend(e: FormEvent) {
    e.preventDefault();
    if (!text.trim() || !user || cooldown) return;
    const cleanText = text.trim();
    setText("");

    await addDoc(collection(db, "chats", chatId, "messages"), {
      senderId: String(user.id),
      text: cleanText,
      createdAt: serverTimestamp(),
    });

    api("/chats/notify", { method: "POST", json: { chat_id: chatId, text: cleanText } }).catch(() => {});

    // Cooldown 2 detik khusus chat CS (AI) supaya tidak spam ke AI gateway.
    if (isCsChat && meta?.cs_mode === "ai") {
      setCooldown(true);
      setTimeout(() => setCooldown(false), SEND_COOLDOWN_MS);
    }
  }

  async function handleSendImage(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    e.target.value = "";
    setSendingImage(true);
    try {
      const imageUrl = await uploadImage(file);
      await addDoc(collection(db, "chats", chatId, "messages"), {
        senderId: String(user.id),
        imageUrl,
        createdAt: serverTimestamp(),
      });
      api("/chats/notify", { method: "POST", json: { chat_id: chatId, image_url: imageUrl } }).catch(() => {});
    } catch (err: any) {
      alert(err.message || "Gagal mengirim foto.");
    } finally {
      setSendingImage(false);
    }
  }

  async function toggleMute() {
    const next = !muted;
    setMuted(next);
    setMenuOpen(false);
    await api(`/chats/${chatId}/mute`, { method: "PUT", json: { muted: next } }).catch(() => {});
  }

  async function handleDeleteChat() {
    if (!confirm("Hapus chat ini dari daftarmu?")) return;
    await api(`/chats/${chatId}`, { method: "DELETE" }).catch(() => {});
    router.push("/chat");
  }

  // Penjual jualan siswa bisa menandai transaksi informal ini selesai,
  // sekaligus langsung kirim kartu permintaan rating ke pembeli.
  const canCompleteSale = !!(user && product && product.seller_id === user.id && product.category === "siswa" && other);

  async function handleCompleteSale(price: number) {
    if (!user || !other) return;
    try {
      const { id: orderId } = await api<{ id: number }>("/orders/siswa/complete", {
        method: "POST",
        json: { buyer_id: other.id, product_id: product?.id, price },
      });
      await sendRatingRequest(user.id, other.id, orderId);
      setCompleteModalOpen(false);
      setMenuOpen(false);
    } catch (err: any) {
      alert(err.message || "Gagal menandai transaksi selesai.");
    }
  }

  return (
    <main className="min-h-screen flex flex-col">
      <div className="sticky top-0 z-20 bg-white border-b border-brand-100 px-2 py-2 flex items-center gap-2 max-w-2xl w-full mx-auto">
        <button onClick={() => router.push("/chat")} className="p-2 text-brand-700" aria-label="Kembali">
          <ArrowLeft size={20} aria-hidden="true" />
        </button>
        {other && (
          <Link href={`/profile/${other.id}`} className="flex items-center gap-3 flex-1 min-w-0">
            <div className="relative w-9 h-9 rounded-full bg-brand-100 overflow-hidden shrink-0">
              {other.profile_photo_url ? (
                <Image src={other.profile_photo_url} alt={other.full_name} fill className="object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-brand-400">
                  <UserRound size={16} aria-hidden="true" />
                </div>
              )}
            </div>
            <div className="min-w-0">
              <span className="font-sub font-medium text-sm truncate block">{other.full_name}</span>
              {isCsChat && (
                <span className="text-xs text-slate-400 font-body">
                  {meta?.cs_mode === "human" ? "Terhubung dengan CS manusia" : "Dibalas otomatis oleh bot"}
                </span>
              )}
            </div>
          </Link>
        )}
        <div className="relative">
          <button onClick={() => setMenuOpen((v) => !v)} className="p-2 text-brand-700" aria-label="Menu chat">
            <MoreVertical size={20} aria-hidden="true" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 top-10 bg-white border border-brand-100 rounded-xl shadow-lg py-1 w-64 z-30">
              {canCompleteSale && (
                <button
                  onClick={() => { setCompleteModalOpen(true); setMenuOpen(false); }}
                  className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-body text-emerald-700 hover:bg-emerald-50"
                >
                  <CheckCircle2 size={16} aria-hidden="true" />
                  Tandai Selesai & Minta Rating
                </button>
              )}
              <button onClick={toggleMute} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-body text-slate-700 hover:bg-brand-50">
                {muted ? <Bell size={16} aria-hidden="true" /> : <BellOff size={16} aria-hidden="true" />}
                {muted ? "Aktifkan notifikasi" : "Senyapkan notifikasi"}
              </button>
              <button onClick={handleDeleteChat} className="w-full flex items-center gap-2 px-4 py-2.5 text-sm font-body text-red-600 hover:bg-red-50">
                <Trash2 size={16} aria-hidden="true" />
                Hapus chat
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-2xl w-full mx-auto flex-1 flex flex-col px-4 py-4">
        <div className="flex-1 overflow-y-auto space-y-2 pb-4">
          {messages.map((m) => {
            const mine = m.senderId === String(user?.id);

            if (m.type === "rating_request") {
              return (
                <div key={m.id} className="flex justify-center py-2">
                  <Link href={`/rating/${m.orderId}`} className="card p-3 flex items-center gap-2 text-sm font-sub text-brand-700 hover:shadow-md">
                    <Star size={16} className="fill-amber-400 text-amber-400" aria-hidden="true" />
                    {m.text || "Pesananmu selesai! Beri rating sekarang"}
                  </Link>
                </div>
              );
            }

            return (
              <div key={m.id} className={`flex flex-col ${mine ? "items-end" : "items-start"}`}>
                {m.isAi && !mine && (
                  <span className="flex items-center gap-1 text-[10px] text-slate-400 font-sub mb-0.5 ml-1">
                    <Bot size={10} aria-hidden="true" /> Bot
                  </span>
                )}
                {m.imageUrl ? (
                  <div className="max-w-[75%] space-y-1">
                    <div className={`relative w-48 h-48 rounded-2xl overflow-hidden ${mine ? "rounded-br-sm ml-auto" : "rounded-bl-sm"}`}>
                      <Image src={m.imageUrl} alt="Foto terkirim" fill className="object-cover" />
                    </div>
                    {m.text && (
                      <div className={`px-3 py-1.5 rounded-xl text-sm font-body ${mine ? "bg-brand-600 text-white ml-auto w-fit" : "bg-white border border-brand-100 w-fit"}`}>
                        {m.text}
                      </div>
                    )}
                  </div>
                ) : (
                  <div
                    className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm font-body whitespace-pre-line ${
                      mine ? "bg-brand-600 text-white rounded-br-sm" : "bg-white border border-brand-100 rounded-bl-sm"
                    }`}
                  >
                    {m.text}
                  </div>
                )}
              </div>
            );
          })}
          {messages.length === 0 && (
            <p className="text-center text-slate-400 font-body text-sm py-8">
              {isCsChat ? "Tanya apa saja ke asisten CS kami, atau ketik 1 untuk bicara dengan manusia." : "Mulai percakapan..."}
            </p>
          )}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={handleSend} className="flex gap-2 pb-20 md:pb-2">
          <label className="btn-secondary flex items-center justify-center px-3 cursor-pointer">
            {sendingImage ? <LoaderCircle size={18} className="animate-spin" aria-hidden="true" /> : <ImageIcon size={18} aria-hidden="true" />}
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleSendImage} className="hidden" disabled={sendingImage} />
          </label>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={cooldown ? "Tunggu sebentar..." : "Tulis pesan..."}
            className="input-field flex-1"
            aria-label="Tulis pesan"
            maxLength={2000}
            disabled={cooldown}
          />
          <button type="submit" disabled={cooldown} className="btn-primary flex items-center justify-center px-4 disabled:opacity-50">
            <Send size={18} aria-hidden="true" />
          </button>
        </form>
      </div>

      {completeModalOpen && product && (
        <CompleteSaleModal
          productName={product.name}
          defaultPrice={product.price}
          onClose={() => setCompleteModalOpen(false)}
          onConfirm={handleCompleteSale}
        />
      )}
    </main>
  );
}

function CompleteSaleModal({
  productName,
  defaultPrice,
  onClose,
  onConfirm,
}: {
  productName: string;
  defaultPrice: number;
  onClose: () => void;
  onConfirm: (price: number) => Promise<void>;
}) {
  const [price, setPrice] = useState(String(defaultPrice));
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    await onConfirm(Number(price));
    setSubmitting(false);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <form onSubmit={handleSubmit} className="relative card p-5 w-full max-w-sm space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-sub font-medium text-brand-700">Tandai Transaksi Selesai</h2>
          <button type="button" onClick={onClose} className="p-1 text-slate-400" aria-label="Tutup">
            <X size={18} aria-hidden="true" />
          </button>
        </div>
        <p className="text-sm text-slate-500 font-body">{productName}</p>
        <div>
          <label htmlFor="sale_price" className="block text-sm font-sub mb-1 text-slate-600">Harga transaksi (Rp)</label>
          <input id="sale_price" type="number" min={0} required value={price} onChange={(e) => setPrice(e.target.value)} className="input-field" />
        </div>
        <p className="text-xs text-slate-400 font-body">
          Pembeli akan langsung dikirimi kartu untuk memberi rating & ulasan di chat ini.
        </p>
        <button type="submit" disabled={submitting} className="btn-primary w-full flex items-center justify-center gap-2">
          {submitting && <LoaderCircle size={16} className="animate-spin" aria-hidden="true" />}
          Konfirmasi Selesai
        </button>
      </form>
    </div>
  );
}
