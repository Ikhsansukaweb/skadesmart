"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { MessageCircleOff, UserRound, Headset } from "lucide-react";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/auth-context";
import { playNotificationSound } from "@/lib/sound";

interface ChatMetaRow {
  id: string;
  other_id: number;
  other_name: string;
  other_photo: string | null;
}

interface LiveChat {
  id: string;
  lastMessage?: string;
  lastMessageAt?: any;
  lastSenderId?: string;
  lastReadAt?: Record<string, any>;
}

interface MergedChat extends ChatMetaRow {
  lastMessage: string;
  lastMessageAt: number;
  unread: boolean;
}

// Chat Page: daftar percakapan REALTIME (subscribe langsung ke Firestore),
// dengan badge belum-dibaca seperti WhatsApp. Nama/foto lawan bicara diambil
// sekali dari SQLite (REST), lalu digabung dengan data realtime Firestore.
export default function ChatListPage() {
  const { user, firebaseReady } = useAuth();
  const [metaMap, setMetaMap] = useState<Record<string, ChatMetaRow>>({});
  const [liveChats, setLiveChats] = useState<LiveChat[]>([]);

  useEffect(() => {
    api<{ chats: ChatMetaRow[] }>("/chats").then((d) => {
      const map: Record<string, ChatMetaRow> = {};
      d.chats.forEach((c) => (map[c.id] = c));
      setMetaMap(map);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!user || !firebaseReady) return;
    const seenAt = new Map<string, number>();
    let firstSnapshot = true;

    const q = query(collection(db, "chats"), where("participants", "array-contains", String(user.id)));
    const unsub = onSnapshot(q, (snap) => {
      const rows = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })) as LiveChat[];

      if (firstSnapshot) {
        rows.forEach((r) => {
          const millis = r.lastMessageAt?.toMillis ? r.lastMessageAt.toMillis() : 0;
          seenAt.set(r.id, millis);
        });
        firstSnapshot = false;
      } else {
        // Bunyikan notifikasi kalau ada pesan baru masuk SAAT user sedang
        // berada di halaman daftar chat ini (bukan di dalam detail chat mana pun).
        rows.forEach((r) => {
          const millis = r.lastMessageAt?.toMillis ? r.lastMessageAt.toMillis() : 0;
          const prev = seenAt.get(r.id) || 0;
          if (millis > prev && r.lastSenderId !== String(user.id)) {
            playNotificationSound();
          }
          seenAt.set(r.id, millis);
        });
      }

      setLiveChats(rows);
    });
    return () => unsub();
  }, [user, firebaseReady]);

  const merged: MergedChat[] = liveChats
    .filter((lc) => metaMap[lc.id])
    .map((lc) => {
      const meta = metaMap[lc.id];
      const lastMessageAt = lc.lastMessageAt?.toMillis ? lc.lastMessageAt.toMillis() : 0;
      const lastReadAt = lc.lastReadAt?.[String(user?.id)];
      const lastReadMillis = lastReadAt?.toMillis ? lastReadAt.toMillis() : 0;
      const unread = !!lc.lastMessage && lc.lastSenderId !== String(user?.id) && lastMessageAt > lastReadMillis;
      return {
        ...meta,
        lastMessage: lc.lastMessage || "Belum ada pesan",
        lastMessageAt,
        unread,
      };
    })
    .sort((a, b) => b.lastMessageAt - a.lastMessageAt);

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-3">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-brand-700">Chat</h1>
          {user?.role !== "cs" && (
            <Link href="/cs/chat" className="btn-secondary flex items-center gap-2 text-sm">
              <Headset size={16} aria-hidden="true" /> Chat CS
            </Link>
          )}
        </div>

        {merged.map((c) => (
          <Link key={c.id} href={`/chat/${c.id}`} className="card p-4 flex items-center gap-3 hover:shadow-md transition-shadow">
            <div className="relative w-11 h-11 rounded-full bg-brand-100 overflow-hidden shrink-0">
              {c.other_photo ? (
                <Image src={c.other_photo} alt={c.other_name} fill className="object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-brand-400">
                  <UserRound size={20} aria-hidden="true" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <span className={`font-sub block ${c.unread ? "font-semibold" : "font-medium"}`}>{c.other_name}</span>
              <span className={`text-sm font-body line-clamp-1 block ${c.unread ? "text-slate-700 font-medium" : "text-slate-500"}`}>
                {c.lastMessage}
              </span>
            </div>
            {c.unread && <span className="w-2.5 h-2.5 rounded-full bg-brand-600 shrink-0" aria-label="Belum dibaca" />}
          </Link>
        ))}
        {merged.length === 0 && Object.keys(metaMap).length === 0 && (
          <div className="flex flex-col items-center gap-2 py-12 text-slate-400">
            <MessageCircleOff size={32} aria-hidden="true" />
            <p className="font-body text-sm">Belum ada percakapan. Mulai chat dari halaman produk.</p>
          </div>
        )}
      </div>
    </main>
  );
}
