"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
import { UserRound, MessageCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import ProductCard, { ProductCardData } from "@/components/ProductCard";
import RatingStars from "@/components/RatingStars";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";

interface PublicUser {
  id: number;
  full_name: string;
  class_name: string;
  role: string;
  profile_photo_url: string | null;
  banner_url: string | null;
}

const ROLE_LABEL: Record<string, string> = {
  siswa: "Siswa",
  kwu_brital: "Staf - Ayam Geprek Brital",
  kwu_laundry: "Staf - Laundry",
  cs: "Customer Service",
  admin: "Admin",
};

// Profil publik siswa lain: foto, banner, kelas, role, produk yang dijual,
// dan rating agregat sebagai penjual.
export default function PublicProfilePage() {
  const { userId } = useParams<{ userId: string }>();
  const { user: me } = useAuth();
  const router = useRouter();

  const [profile, setProfile] = useState<PublicUser | null>(null);
  const [products, setProducts] = useState<ProductCardData[]>([]);
  const [rating, setRating] = useState({ avg_rating: 0, rating_count: 0 });

  useEffect(() => {
    api<{ user: PublicUser; products: ProductCardData[]; rating: typeof rating }>(`/users/${userId}`)
      .then((d) => {
        setProfile(d.user);
        setProducts(d.products);
        setRating(d.rating);
      })
      .catch(() => setProfile(null));
  }, [userId]);

  async function handleChat() {
    if (!profile) return;
    const { chat } = await api<{ chat: { id: string } }>("/chats", {
      method: "POST",
      json: { seller_id: profile.id },
    });
    router.push(`/chat/${chat.id}`);
  }

  if (!profile) {
    return (
      <main className="min-h-screen">
        <Navbar />
        <p className="text-center py-10 text-slate-400 font-body">Memuat profil...</p>
      </main>
    );
  }

  const isMe = me?.id === profile.id;

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-3xl mx-auto">
        <div className="relative w-full h-24 bg-brand-100">
          {profile.banner_url && <Image src={profile.banner_url} alt="Banner" fill className="object-cover" />}
        </div>

        <div className="px-4 -mt-8 pb-4">
          <div className="relative w-20 h-20 rounded-full bg-brand-100 overflow-hidden border-4 border-white shrink-0">
            {profile.profile_photo_url ? (
              <Image src={profile.profile_photo_url} alt={profile.full_name} fill className="object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-brand-400">
                <UserRound size={32} aria-hidden="true" />
              </div>
            )}
          </div>

          <div className="mt-3 flex items-start justify-between gap-3">
            <div className="space-y-1 min-w-0">
              <h1 className="text-xl font-sub font-medium truncate">{profile.full_name}</h1>
              <p className="text-sm text-slate-500 font-body">{profile.class_name} - {ROLE_LABEL[profile.role] || profile.role}</p>
              {rating.rating_count > 0 && <RatingStars value={rating.avg_rating} count={rating.rating_count} />}
            </div>
            {!isMe && (
              <button onClick={handleChat} className="btn-primary flex items-center gap-2 text-sm shrink-0">
                <MessageCircle size={16} aria-hidden="true" /> Chat
              </button>
            )}
          </div>
        </div>

        <div className="px-4 pb-8">
          <h2 className="text-xl mb-3 text-brand-700">Produk yang dijual</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
            {products.length === 0 && <p className="col-span-full text-slate-400 font-body text-sm">Belum ada produk yang dijual.</p>}
          </div>
        </div>
      </div>
    </main>
  );
}
