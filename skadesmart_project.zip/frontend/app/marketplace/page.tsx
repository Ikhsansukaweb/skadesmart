"use client";

import Link from "next/link";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Search, UtensilsCrossed, ShoppingBag, LayoutGrid, Plus } from "lucide-react";
import Navbar from "@/components/Navbar";
import ProductCard, { ProductCardData } from "@/components/ProductCard";
import { api } from "@/lib/api";

// Laundry sengaja tidak ada di filter - lihat banner "Cara Pesan Laundry" di Home.
const FILTERS = [
  { value: "", label: "Semua", icon: LayoutGrid },
  { value: "kwu_brital", label: "Ayam Geprek Brital", icon: UtensilsCrossed },
  { value: "siswa", label: "Jualan Siswa", icon: ShoppingBag },
];

function MarketplaceContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const category = searchParams.get("category") || "";

  const [products, setProducts] = useState<ProductCardData[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const query = new URLSearchParams();
    if (category) query.set("category", category);
    if (search) query.set("search", search);
    api<{ products: ProductCardData[] }>(`/products?${query.toString()}`)
      .then((d) => setProducts(d.products))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [category, search]);

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-5">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-brand-700">Marketplace</h1>
          <div className="flex gap-2">
            <Link href="/product/mine" className="btn-secondary flex items-center gap-2 text-sm">
              Produk Saya
            </Link>
            <Link href="/product/add" className="btn-primary flex items-center gap-2 text-sm">
              <Plus size={16} aria-hidden="true" /> Jual Produk
            </Link>
          </div>
        </div>

        <div className="relative">
          <input
            className="input-field pr-10"
            placeholder="Cari produk..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Cari produk"
          />
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Filter kategori produk">
          {FILTERS.map(({ value, label, icon: Icon }) => (
            <button
              key={value}
              role="tab"
              aria-selected={category === value}
              onClick={() => router.push(value ? `/marketplace?category=${value}` : "/marketplace")}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-sub whitespace-nowrap transition-colors ${
                category === value ? "bg-brand-600 text-white" : "bg-white border border-brand-200 text-brand-700"
              }`}
            >
              <Icon size={16} aria-hidden="true" />
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <p className="text-slate-400 font-body text-sm">Memuat produk...</p>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
            {products.length === 0 && (
              <p className="col-span-full text-slate-400 font-body text-sm">Tidak ada produk ditemukan.</p>
            )}
          </div>
        )}
      </div>
    </main>
  );
}

export default function MarketplacePage() {
  return (
    <Suspense fallback={null}>
      <MarketplaceContent />
    </Suspense>
  );
}
