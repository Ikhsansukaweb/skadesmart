"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Users,
  Package,
  ShoppingBag,
  Clock,
  Wallet,
  Settings2,
  LoaderCircle,
  ShieldCheck,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

interface Summary {
  totalUsers: number;
  totalProducts: number;
  totalOrders: number;
  pendingOrders: number;
  revenue: number;
}

interface AdminUser {
  id: number;
  nisn: string;
  full_name: string;
  class_name: string;
  role: string;
  created_at: string;
}

const ROLE_OPTIONS = ["siswa", "kwu_brital", "kwu_laundry", "cs", "admin"];

// Admin Dashboard: ringkasan statistik, kelola role user, akses cepat ke Edit KWU
// (bagian 4, halaman #11). Semua endpoint yang dipanggil di sini wajib role admin.
export default function AdminDashboardPage() {
  const { user } = useAuth();
  const [summary, setSummary] = useState<Summary | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  function load() {
    api<Summary>("/admin/dashboard/summary").then(setSummary).catch(() => {});
    api<{ users: AdminUser[] }>("/admin/users").then((d) => setUsers(d.users)).catch(() => {});
  }

  useEffect(load, []);

  async function changeRole(id: number, role: string) {
    setUpdatingId(id);
    try {
      await api(`/admin/users/${id}/role`, { method: "PUT", json: { role } });
      load();
    } finally {
      setUpdatingId(null);
    }
  }

  if (user && user.role !== "admin") {
    return (
      <main className="min-h-screen">
        <Navbar />
        <p className="text-center py-10 text-slate-400 font-body">Halaman ini khusus admin.</p>
      </main>
    );
  }

  const cards = summary
    ? [
        { label: "Total Pengguna", value: summary.totalUsers, icon: Users },
        { label: "Produk Aktif", value: summary.totalProducts, icon: Package },
        { label: "Total Pesanan", value: summary.totalOrders, icon: ShoppingBag },
        { label: "Pesanan Pending", value: summary.pendingOrders, icon: Clock },
        { label: "Pendapatan", value: `Rp${summary.revenue.toLocaleString("id-ID")}`, icon: Wallet },
      ]
    : [];

  return (
    <main className="min-h-screen pb-20 md:pb-8">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-brand-700 flex items-center gap-2">
            <ShieldCheck size={22} aria-hidden="true" /> Dashboard Admin
          </h1>
          <Link href="/admin/kwu" className="btn-secondary flex items-center gap-2 text-sm">
            <Settings2 size={16} aria-hidden="true" /> Edit KWU
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {cards.map(({ label, value, icon: Icon }) => (
            <div key={label} className="card p-4 text-center space-y-1">
              <Icon size={20} className="mx-auto text-brand-500" aria-hidden="true" />
              <p className="font-heading text-lg text-brand-700">{value}</p>
              <p className="text-xs text-slate-500 font-body">{label}</p>
            </div>
          ))}
          {!summary && <p className="col-span-full text-slate-400 font-body text-sm">Memuat ringkasan...</p>}
        </div>

        <div>
          <h2 className="text-xl mb-3 text-brand-700">Kelola Pengguna</h2>
          <div className="card overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-brand-50 text-brand-700 font-sub">
                <tr>
                  <th className="text-left px-3 py-2">Nama</th>
                  <th className="text-left px-3 py-2">NISN</th>
                  <th className="text-left px-3 py-2">Kelas</th>
                  <th className="text-left px-3 py-2">Role</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-brand-100">
                    <td className="px-3 py-2 font-body">{u.full_name}</td>
                    <td className="px-3 py-2 font-body">{u.nisn}</td>
                    <td className="px-3 py-2 font-body">{u.class_name}</td>
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        <select
                          value={u.role}
                          onChange={(e) => changeRole(u.id, e.target.value)}
                          disabled={updatingId === u.id}
                          className="input-field py-1 text-xs"
                        >
                          {ROLE_OPTIONS.map((r) => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </select>
                        {updatingId === u.id && <LoaderCircle size={14} className="animate-spin text-brand-500" aria-hidden="true" />}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {users.length === 0 && <p className="p-4 text-slate-400 font-body text-sm">Belum ada pengguna.</p>}
          </div>
        </div>
      </div>
    </main>
  );
}
