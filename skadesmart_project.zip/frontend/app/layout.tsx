import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";
import { CartProvider } from "@/lib/cart-context";
import CartDrawer from "@/components/CartDrawer";
import Footer from "@/components/Footer";
import NotificationSound from "@/components/NotificationSound";

// Font di-load via <link> biasa (fetch di browser saat runtime), BUKAN
// next/font/google, supaya proses `next build` tidak butuh akses internet
// ke fonts.googleapis.com (server VPS/CI sekolah bisa saja membatasi
// koneksi keluar). Nama family didaftarkan langsung di tailwind.config.ts
// lewat CSS variable di globals.css.
export const metadata: Metadata = {
  title: "SkadesMart - Marketplace Internal SMKN 1 Depok Sleman",
  description:
    "Marketplace internal sekolah untuk unit KWU (Ayam Geprek Brital, Laundry) dan jualan bebas siswa.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Saira:wght@400;500;600&family=Smooch+Sans:wght@400;500&display=swap"
        />
      </head>
      <body>
        <AuthProvider>
          <CartProvider>
            {children}
            <CartDrawer />
            <Footer />
            <NotificationSound />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
