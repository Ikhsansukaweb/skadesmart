import { Request, Response, NextFunction } from "express";

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({ error: "Endpoint tidak ditemukan." });
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  console.error("[error]", err);
  const status = err.status || 500;
  res.status(status).json({ error: err.message || "Terjadi kesalahan pada server." });
}
