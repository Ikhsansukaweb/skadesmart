import rateLimit from "express-rate-limit";

// Endpoint sensitif login/register — dibatasi ketat per-IP karena rawan brute force.
export const strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Terlalu banyak percobaan. Coba lagi beberapa menit lagi." },
});

// Limiter TERPISAH untuk upload gambar, supaya kuotanya tidak bercampur dengan
// percobaan login (sebelumnya keduanya pakai strictLimiter yang sama, jadi
// upload ikut kena limit gara-gara login berkali-kali saat testing).
export const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Terlalu banyak upload. Coba lagi beberapa menit lagi." },
});

// Endpoint baca data umum (marketplace, produk, chat list).
export const readLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Terlalu banyak permintaan. Coba lagi sebentar." },
});

// Default umum untuk endpoint publik lain.
export const defaultLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
});
