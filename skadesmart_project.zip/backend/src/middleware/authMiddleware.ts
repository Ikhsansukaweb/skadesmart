import { Request, Response, NextFunction } from "express";
import { verifyToken, AUTH_COOKIE_NAME, JwtPayload } from "../utils/jwt";

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

/**
 * Wajib untuk semua endpoint yang butuh identitas user.
 * Membaca JWT dari httpOnly cookie (bukan Authorization header/localStorage),
 * supaya token tidak bisa dibaca lewat JS jika terjadi XSS.
 */
export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const token = req.cookies?.[AUTH_COOKIE_NAME];

  if (!token) {
    return res.status(401).json({ error: "Tidak terautentikasi. Silakan login." });
  }

  try {
    req.user = verifyToken(token);
    next();
  } catch (err) {
    return res.status(401).json({ error: "Sesi tidak valid atau kedaluwarsa. Silakan login ulang." });
  }
}
