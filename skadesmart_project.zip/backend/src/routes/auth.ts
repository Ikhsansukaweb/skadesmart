import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "../db";
import { validate } from "../middleware/validate";
import { authMiddleware } from "../middleware/authMiddleware";
import { strictLimiter } from "../middleware/rateLimiter";
import { loginSchema, registerSchema, fcmTokenSchema } from "../validators/authValidator";
import { signToken, AUTH_COOKIE_NAME } from "../utils/jwt";
import { createFirebaseCustomToken } from "../services/firebaseAdmin";

const router = Router();

const isProd = process.env.NODE_ENV === "production";
const cookieOptions = {
  httpOnly: true,
  secure: isProd,
  sameSite: "lax" as const,
  maxAge: 2 * 24 * 60 * 60 * 1000,
  path: "/",
};

async function issueSession(res: any, user: any) {
  const token = signToken({ user_id: user.id, nisn: user.nisn, role: user.role });
  const firebaseToken = await createFirebaseCustomToken(user.id);
  res.cookie(AUTH_COOKIE_NAME, token, cookieOptions);
  return firebaseToken;
}

// Login KETAT: NISN harus sudah terdaftar (lewat /auth/register atau seed
// data sekolah) dan password harus cocok dengan hash tersimpan. TIDAK ADA
// auto-register di sini dan TIDAK ADA password yang "keterima asal isi" -
// keduanya bug dari versi sebelumnya, sekarang diperbaiki.
router.post("/login", strictLimiter, validate(loginSchema), async (req, res, next) => {
  try {
    const { nisn, password } = req.body;

    const user = db.prepare("SELECT * FROM users WHERE nisn = ?").get(nisn) as any;
    if (!user) {
      return res.status(404).json({
        error: "NISN belum terdaftar. Silakan daftar akun baru dulu.",
        code: "NISN_NOT_FOUND",
      });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: "NISN atau password salah." });
    }

    const firebaseToken = await issueSession(res, user);
    res.json({
      user: {
        id: user.id,
        nisn: user.nisn,
        full_name: user.full_name,
        class_name: user.class_name,
        role: user.role,
        profile_photo_url: user.profile_photo_url,
      },
      firebaseToken,
    });
  } catch (err) {
    next(err);
  }
});

// Registrasi akun baru - satu-satunya jalur untuk NISN yang belum ada di
// database. Ditolak kalau NISN sudah dipakai (harus login, bukan daftar lagi).
router.post("/register", strictLimiter, validate(registerSchema), async (req, res, next) => {
  try {
    const { nisn, password, full_name, class_name } = req.body;

    const existing = db.prepare("SELECT id FROM users WHERE nisn = ?").get(nisn);
    if (existing) {
      return res.status(409).json({ error: "NISN sudah terdaftar. Silakan login." });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const info = db
      .prepare(
        `INSERT INTO users (nisn, password_hash, full_name, class_name, role)
         VALUES (?, ?, ?, ?, 'siswa')`
      )
      .run(nisn, password_hash, full_name, class_name);

    const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid) as any;
    const firebaseToken = await issueSession(res, user);

    res.status(201).json({
      user: { id: user.id, nisn, full_name, class_name, role: "siswa" },
      firebaseToken,
    });
  } catch (err) {
    next(err);
  }
});

router.post("/logout", (req, res) => {
  res.clearCookie(AUTH_COOKIE_NAME, { path: "/" });
  res.json({ message: "Logout berhasil." });
});

router.get("/me", authMiddleware, (req, res) => {
  const user = db
    .prepare(
      `SELECT id, nisn, full_name, class_name, role, profile_photo_url, notif_enabled
       FROM users WHERE id = ?`
    )
    .get(req.user!.user_id);
  if (!user) return res.status(404).json({ error: "User tidak ditemukan." });
  res.json({ user });
});

// GET /api/auth/firebase-token - minta ULANG Firebase Custom Token kapan saja
// selama cookie JWT masih valid (bukan cuma sekali pas login). Dipakai
// frontend untuk re-authenticate ke Firebase setiap kali halaman di-refresh,
// karena sesi Firebase Auth di browser tidak selalu ter-restore mulus -
// tanpa ini, semua listener Firestore (chat, status pesanan) akan gagal
// permission-denied diam-diam setelah refresh sampai user login ulang manual.
router.get("/firebase-token", authMiddleware, strictLimiter, async (req, res) => {
  const firebaseToken = await createFirebaseCustomToken(req.user!.user_id);
  if (!firebaseToken) {
    return res.status(503).json({ error: "Firebase belum dikonfigurasi di server." });
  }
  res.json({ firebaseToken });
});

router.post("/fcm-token", authMiddleware, strictLimiter, validate(fcmTokenSchema), (req, res) => {
  db.prepare("UPDATE users SET fcm_token = ?, updated_at = datetime('now') WHERE id = ?").run(
    req.body.fcm_token,
    req.user!.user_id
  );
  res.json({ message: "Token notifikasi tersimpan." });
});

export default router;
