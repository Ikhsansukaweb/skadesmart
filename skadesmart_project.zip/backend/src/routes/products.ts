import { Router } from "express";
import { db } from "../db";
import { authMiddleware } from "../middleware/authMiddleware";
import { validate } from "../middleware/validate";
import { readLimiter, defaultLimiter } from "../middleware/rateLimiter";
import {
  createProductSchema,
  updateProductSchema,
  listProductsQuerySchema,
} from "../validators/productValidator";
import { sanitizeText } from "../utils/sanitize";
import { cache, invalidateByPrefix } from "../services/cache";

const router = Router();

function attachImages(productId: number, imageUrls: string[]) {
  db.prepare("DELETE FROM product_images WHERE product_id = ?").run(productId);
  const insert = db.prepare(
    "INSERT INTO product_images (product_id, image_url, sort_order) VALUES (?, ?, ?)"
  );
  imageUrls.forEach((url, idx) => insert.run(productId, url, idx));
  db.prepare("UPDATE products SET image_url = ? WHERE id = ?").run(imageUrls[0] || null, productId);
}

// GET /api/products - daftar produk (marketplace), filter kategori & search, cached.
// Menyertakan status toko penjual (seller_shop_open) supaya frontend bisa
// menandai "Tutup" tanpa request tambahan.
router.get("/", readLimiter, validate(listProductsQuerySchema, "query"), (req, res) => {
  const { category, search, seller_id, page, limit } = req.query as any;
  const cacheKey = `products:${category || "all"}:${search || ""}:${seller_id || ""}:${page}:${limit}`;

  const cached = cache.get(cacheKey);
  if (cached) return res.json(cached);

  const offset = (page - 1) * limit;
  let where = "WHERE p.is_active = 1";
  const params: any[] = [];

  if (category) {
    where += " AND p.category = ?";
    params.push(category);
  }
  if (seller_id) {
    where += " AND p.seller_id = ?";
    params.push(seller_id);
  }
  if (search) {
    where += " AND p.name LIKE ?";
    params.push(`%${search}%`);
  }

  const rows = db
    .prepare(
      `SELECT p.*, u.full_name AS seller_name, u.class_name AS seller_class, u.shop_open AS seller_shop_open,
              (SELECT ROUND(AVG(score),1) FROM ratings r WHERE r.product_id = p.id AND r.is_hidden = 0) AS avg_rating,
              (SELECT COUNT(*) FROM ratings r WHERE r.product_id = p.id AND r.is_hidden = 0) AS rating_count
       FROM products p
       JOIN users u ON u.id = p.seller_id
       ${where}
       ORDER BY p.created_at DESC
       LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);

  const result = { products: rows, page, limit };
  cache.set(cacheKey, result, 45);
  res.json(result);
});

// GET /api/products/mine - produk milik user yang login (untuk halaman
// "Kelola Produk Saya"), termasuk yang stoknya 0, TIDAK termasuk yang sudah dihapus.
router.get("/mine", authMiddleware, readLimiter, (req, res) => {
  const rows = db
    .prepare(
      `SELECT p.*,
              (SELECT ROUND(AVG(score),1) FROM ratings r WHERE r.product_id = p.id AND r.is_hidden = 0) AS avg_rating,
              (SELECT COUNT(*) FROM ratings r WHERE r.product_id = p.id AND r.is_hidden = 0) AS rating_count
       FROM products p WHERE p.seller_id = ? AND p.is_active = 1
       ORDER BY p.created_at DESC`
    )
    .all(req.user!.user_id);
  res.json({ products: rows });
});

// GET /api/products/:id - detail produk + semua foto galeri + kelas penjual.
router.get("/:id", readLimiter, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "ID produk tidak valid." });

  const product = db
    .prepare(
      `SELECT p.*, u.full_name AS seller_name, u.class_name AS seller_class, u.id AS seller_id,
              u.profile_photo_url AS seller_photo, u.shop_open AS seller_shop_open
       FROM products p JOIN users u ON u.id = p.seller_id
       WHERE p.id = ? AND p.is_active = 1`
    )
    .get(id) as any;

  if (!product) return res.status(404).json({ error: "Produk tidak ditemukan." });

  const images = db
    .prepare("SELECT image_url FROM product_images WHERE product_id = ? ORDER BY sort_order ASC")
    .all(id)
    .map((r: any) => r.image_url);

  const ratings = db
    .prepare(
      `SELECT r.score, r.comment, r.created_at, u.full_name AS buyer_name
       FROM ratings r JOIN users u ON u.id = r.buyer_id
       WHERE r.product_id = ? AND r.is_hidden = 0
       ORDER BY r.created_at DESC LIMIT 20`
    )
    .all(id);

  res.json({ product: { ...product, images: images.length ? images : (product.image_url ? [product.image_url] : []) }, ratings });
});

// POST /api/products - siswa (atau staf kwu_brital) menambahkan produk.
router.post("/", authMiddleware, defaultLimiter, validate(createProductSchema), (req, res) => {
  const { name, description, price, stock, category, image_urls } = req.body;

  if (category === "kwu_brital" && !["kwu_brital", "admin"].includes(req.user!.role)) {
    return res.status(403).json({
      error: "Hanya staf unit KWU Brital yang bisa menambahkan produk untuk kategori ini.",
    });
  }

  const info = db
    .prepare(
      `INSERT INTO products (seller_id, category, name, description, price, stock, image_url)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(req.user!.user_id, category, name, sanitizeText(description || ""), price, stock, image_urls?.[0] || null);

  const productId = Number(info.lastInsertRowid);
  if (image_urls?.length) attachImages(productId, image_urls);

  invalidateByPrefix("products:");
  res.status(201).json({ id: productId });
});

// PUT /api/products/:id - hanya pemilik produk (atau admin) yang boleh edit,
// termasuk mengurangi/menambah stok dan mengubah harga.
router.put("/:id", authMiddleware, defaultLimiter, validate(updateProductSchema), (req, res) => {
  const id = Number(req.params.id);
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(id) as any;
  if (!product) return res.status(404).json({ error: "Produk tidak ditemukan." });
  if (product.seller_id !== req.user!.user_id && req.user!.role !== "admin") {
    return res.status(403).json({ error: "Kamu bukan pemilik produk ini." });
  }

  const { image_urls, ...fields } = req.body;
  const setClauses: string[] = [];
  const values: any[] = [];
  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined) continue;
    setClauses.push(`${key} = ?`);
    values.push(key === "description" ? sanitizeText(String(value)) : typeof value === "boolean" ? (value ? 1 : 0) : value);
  }

  if (setClauses.length > 0) {
    values.push(id);
    db.prepare(`UPDATE products SET ${setClauses.join(", ")}, updated_at = datetime('now') WHERE id = ?`).run(...values);
  }
  if (image_urls?.length) attachImages(id, image_urls);

  invalidateByPrefix("products:");
  res.json({ message: "Produk diperbarui." });
});

// DELETE /api/products/:id - soft delete (is_active = 0), pemilik SENDIRI atau
// admin. Siswa/kwu_brital bisa hapus jualannya sendiri kapan saja.
router.delete("/:id", authMiddleware, defaultLimiter, (req, res) => {
  const id = Number(req.params.id);
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(id) as any;
  if (!product) return res.status(404).json({ error: "Produk tidak ditemukan." });
  if (product.seller_id !== req.user!.user_id && req.user!.role !== "admin") {
    return res.status(403).json({ error: "Kamu bukan pemilik produk ini." });
  }
  db.prepare("UPDATE products SET is_active = 0, updated_at = datetime('now') WHERE id = ?").run(id);
  invalidateByPrefix("products:");
  res.json({ message: "Produk dihapus." });
});

export default router;
