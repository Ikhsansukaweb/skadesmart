import { Router } from "express";
import { db } from "../db";
import { authMiddleware } from "../middleware/authMiddleware";
import { requireRole } from "../middleware/roleMiddleware";
import { validate } from "../middleware/validate";
import { defaultLimiter, readLimiter } from "../middleware/rateLimiter";
import { moderateContentSchema, ticketStatusSchema } from "../validators/adminValidator";

const router = Router();

// Semua endpoint CS wajib JWT valid role cs/admin.
router.use(authMiddleware, requireRole(["cs", "admin"]));

router.get("/tickets", readLimiter, (req, res) => {
  const tickets = db
    .prepare(
      `SELECT t.*, u.full_name, u.class_name FROM cs_tickets t
       JOIN users u ON u.id = t.user_id ORDER BY t.created_at DESC`
    )
    .all();
  res.json({ tickets });
});

router.put("/tickets/:id", defaultLimiter, validate(ticketStatusSchema), (req, res) => {
  const id = Number(req.params.id);
  db.prepare("UPDATE cs_tickets SET status = ?, updated_at = datetime('now') WHERE id = ?").run(req.body.status, id);
  res.json({ message: "Status tiket diperbarui." });
});

// Daftar semua pengguna - dipakai dashboard CS untuk cari & moderasi akun.
router.get("/users", readLimiter, (req, res) => {
  const users = db
    .prepare("SELECT id, nisn, full_name, class_name, role, created_at FROM users ORDER BY created_at DESC")
    .all();
  res.json({ users });
});

// CS bisa menghapus akun bermasalah (bukan cuma admin), sesuai kewenangan
// dashboard CS. Admin sendiri tidak bisa dihapus lewat endpoint ini untuk
// mencegah kecelakaan.
router.delete("/users/:id", defaultLimiter, (req, res) => {
  const id = Number(req.params.id);
  const target = db.prepare("SELECT role FROM users WHERE id = ?").get(id) as any;
  if (!target) return res.status(404).json({ error: "Pengguna tidak ditemukan." });
  if (target.role === "admin") {
    return res.status(403).json({ error: "Akun admin tidak bisa dihapus lewat dashboard CS." });
  }
  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  res.json({ message: "Akun dihapus." });
});

// Moderasi chat bermasalah (dilaporkan) - metadata saja, isi pesan tetap di Firestore.
router.put("/chat/:id/moderate", defaultLimiter, validate(moderateContentSchema), (req, res) => {
  res.json({ message: "Status moderasi chat dicatat.", chatId: req.params.id, is_hidden: req.body.is_hidden });
});

router.put("/rating/:id/moderate", defaultLimiter, validate(moderateContentSchema), (req, res) => {
  const id = Number(req.params.id);
  db.prepare("UPDATE ratings SET is_hidden = ? WHERE id = ?").run(req.body.is_hidden ? 1 : 0, id);
  res.json({ message: "Status moderasi rating diperbarui." });
});

export default router;
