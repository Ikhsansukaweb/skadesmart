import { Router } from "express";
import crypto from "crypto";
import { z } from "zod";
import { db } from "../db";
import { authMiddleware } from "../middleware/authMiddleware";
import { validate } from "../middleware/validate";
import { defaultLimiter, readLimiter } from "../middleware/rateLimiter";
import { createChatSchema, notifyChatMessageSchema } from "../validators/chatValidator";
import {
  sendPushNotification,
  createFirestoreChatDoc,
  mirrorChatMessage,
  sendSystemChatMessage,
} from "../services/firebaseAdmin";
import { sanitizeText } from "../utils/sanitize";
import { askCsAi } from "../services/aiChat";

const router = Router();

const muteSchema = z.object({ muted: z.boolean() }).strict();

// Cooldown 2 detik per chat sebelum AI CS boleh dipanggil lagi, supaya siswa
// tidak bisa spam request ke AI gateway. In-memory saja (cukup untuk 1
// instance server; kalau di-scale ke banyak instance, pindahkan ke Redis).
const lastAiTriggerAt = new Map<string, number>();
const AI_COOLDOWN_MS = 2000;

// POST /api/chats - buat/ambil chat room antara dua orang. SATU chat room per
// PASANGAN orang saja (bukan per produk) - sebelumnya product_id ikut dipakai
// untuk mencari chat lama, jadi chat dari produk berbeda (atau dari halaman
// profil vs halaman produk) dianggap chat BARU meski orangnya sama persis.
// Sekarang product_id cuma metadata informatif, dan pencarian chat lama
// mengecek KEDUA arah (siapa pun yang lebih dulu memulai chat).
router.post("/", authMiddleware, defaultLimiter, validate(createChatSchema), async (req, res) => {
  const { seller_id, product_id } = req.body;
  const myId = req.user!.user_id;

  if (seller_id === myId) {
    return res.status(400).json({ error: "Tidak bisa membuat chat dengan diri sendiri." });
  }

  const existing = db
    .prepare(
      `SELECT * FROM chats
       WHERE (buyer_id = ? AND seller_id = ?) OR (buyer_id = ? AND seller_id = ?)`
    )
    .get(myId, seller_id, seller_id, myId) as any;

  if (existing) {
    // Kalau chat lama belum punya konteks produk dan sekarang ada, simpan
    // (murni informatif, tidak memengaruhi pencarian chat lain).
    if (!existing.product_id && product_id) {
      db.prepare("UPDATE chats SET product_id = ? WHERE id = ?").run(product_id, existing.id);
      existing.product_id = product_id;
    }
    await createFirestoreChatDoc(existing.id, existing.buyer_id, existing.seller_id);
    return res.json({ chat: existing });
  }

  const chatId = crypto.randomUUID();
  db.prepare(
    `INSERT INTO chats (id, buyer_id, seller_id, product_id) VALUES (?, ?, ?, ?)`
  ).run(chatId, req.user!.user_id, seller_id, product_id || null);

  await createFirestoreChatDoc(chatId, req.user!.user_id, seller_id);

  const chat = db.prepare("SELECT * FROM chats WHERE id = ?").get(chatId);
  res.status(201).json({ chat });
});

// GET /api/chats - daftar chat milik user, termasuk foto profil lawan bicara.
// Dipakai frontend untuk lookup nama/foto sekali di awal; urutan & status
// belum-dibaca-nya sendiri di-subscribe realtime langsung ke Firestore.
router.get("/", authMiddleware, readLimiter, (req, res) => {
  const rows = db
    .prepare(
      `SELECT c.*,
              CASE WHEN c.buyer_id = ? THEN us.full_name ELSE ub.full_name END AS other_name,
              CASE WHEN c.buyer_id = ? THEN us.id ELSE ub.id END AS other_id,
              CASE WHEN c.buyer_id = ? THEN us.profile_photo_url ELSE ub.profile_photo_url END AS other_photo
       FROM chats c
       JOIN users ub ON ub.id = c.buyer_id
       JOIN users us ON us.id = c.seller_id
       WHERE c.buyer_id = ? OR c.seller_id = ?
       ORDER BY COALESCE(c.last_message_at, c.created_at) DESC`
    )
    .all(req.user!.user_id, req.user!.user_id, req.user!.user_id, req.user!.user_id, req.user!.user_id);
  res.json({ chats: rows });
});

// GET /api/chats/:id - metadata satu chat + profil lawan bicara + info produk
// (kalau ada) supaya penjual bisa menandai transaksi selesai langsung dari chat.
router.get("/:id", authMiddleware, readLimiter, (req, res) => {
  const chat = db.prepare("SELECT * FROM chats WHERE id = ?").get(req.params.id) as any;
  if (!chat) return res.status(404).json({ error: "Chat tidak ditemukan." });
  if (chat.buyer_id !== req.user!.user_id && chat.seller_id !== req.user!.user_id) {
    return res.status(403).json({ error: "Kamu bukan partisipan chat ini." });
  }

  const otherId = chat.buyer_id === req.user!.user_id ? chat.seller_id : chat.buyer_id;
  const other = db
    .prepare("SELECT id, full_name, profile_photo_url, role FROM users WHERE id = ?")
    .get(otherId);

  const product = chat.product_id
    ? db.prepare("SELECT id, name, price, category, seller_id FROM products WHERE id = ?").get(chat.product_id)
    : null;

  res.json({ chat, other, product });
});

// PUT /api/chats/:id/mute - senyapkan/aktifkan notifikasi push untuk chat ini
// (khusus sisi yang minta, bukan dua-duanya).
router.put("/:id/mute", authMiddleware, defaultLimiter, validate(muteSchema), (req, res) => {
  const chat = db.prepare("SELECT * FROM chats WHERE id = ?").get(req.params.id) as any;
  if (!chat) return res.status(404).json({ error: "Chat tidak ditemukan." });
  if (chat.buyer_id !== req.user!.user_id && chat.seller_id !== req.user!.user_id) {
    return res.status(403).json({ error: "Kamu bukan partisipan chat ini." });
  }
  const column = chat.buyer_id === req.user!.user_id ? "muted_by_buyer" : "muted_by_seller";
  db.prepare(`UPDATE chats SET ${column} = ? WHERE id = ?`).run(req.body.muted ? 1 : 0, req.params.id);
  res.json({ message: "Status senyapkan diperbarui." });
});

// DELETE /api/chats/:id - hapus chat dari daftar (metadata SQLite saja; riwayat
// pesan di Firestore tetap ada kalau lawan bicara belum menghapus juga).
router.delete("/:id", authMiddleware, defaultLimiter, (req, res) => {
  const chat = db.prepare("SELECT * FROM chats WHERE id = ?").get(req.params.id) as any;
  if (!chat) return res.status(404).json({ error: "Chat tidak ditemukan." });
  if (chat.buyer_id !== req.user!.user_id && chat.seller_id !== req.user!.user_id) {
    return res.status(403).json({ error: "Kamu bukan partisipan chat ini." });
  }
  db.prepare("DELETE FROM chats WHERE id = ?").run(req.params.id);
  res.json({ message: "Chat dihapus." });
});

// POST /api/chats/notify - dipanggil client setelah kirim pesan (teks/foto) ke
// Firestore. Backend: (1) update metadata SQLite, (2) mirror last message ke
// Firestore untuk daftar chat realtime, (3) kirim push notification kalau
// penerima tidak menyenyapkan chat ini.
router.post("/notify", authMiddleware, defaultLimiter, validate(notifyChatMessageSchema), async (req, res, next) => {
  try {
    const { chat_id, text, image_url } = req.body;
    const chat = db.prepare("SELECT * FROM chats WHERE id = ?").get(chat_id) as any;
    if (!chat) return res.status(404).json({ error: "Chat tidak ditemukan." });
    if (chat.buyer_id !== req.user!.user_id && chat.seller_id !== req.user!.user_id) {
      return res.status(403).json({ error: "Kamu bukan partisipan chat ini." });
    }

    const cleanText = text ? sanitizeText(text) : "";
    const previewText = cleanText || "Mengirim foto";
    const recipientId = chat.buyer_id === req.user!.user_id ? chat.seller_id : chat.buyer_id;
    const recipientMuted = chat.buyer_id === req.user!.user_id ? chat.muted_by_seller : chat.muted_by_buyer;

    db.prepare(
      `UPDATE chats SET last_message = ?, last_sender_id = ?, last_message_at = datetime('now') WHERE id = ?`
    ).run(previewText.slice(0, 200), req.user!.user_id, chat_id);

    await mirrorChatMessage(chat_id, { lastMessage: previewText.slice(0, 200), lastSenderId: req.user!.user_id });

    if (!recipientMuted) {
      const recipient = db.prepare("SELECT fcm_token, notif_enabled FROM users WHERE id = ?").get(recipientId) as any;
      if (recipient?.notif_enabled) {
        const sender = db.prepare("SELECT full_name FROM users WHERE id = ?").get(req.user!.user_id) as any;
        await sendPushNotification(
          recipient.fcm_token,
          `Pesan baru dari ${sender?.full_name || "pengguna"}`,
          previewText.slice(0, 120),
          { link: `/chat/${chat_id}`, chatId: chat_id }
        );
      }
    }

    // --- AI CS Bot ---
    // Kalau lawan bicara di chat ini adalah akun CS, dan chat belum
    // dieskalasi ke manusia, balas otomatis pakai AI - kecuali user ketik
    // "1" (eskalasi) atau lagi kena cooldown spam.
    const buyerRole = (db.prepare("SELECT role FROM users WHERE id = ?").get(chat.buyer_id) as any)?.role;
    const sellerRole = (db.prepare("SELECT role FROM users WHERE id = ?").get(chat.seller_id) as any)?.role;
    const csUserId = buyerRole === "cs" ? chat.buyer_id : sellerRole === "cs" ? chat.seller_id : null;
    const iAmTheCsAccount = csUserId === req.user!.user_id;

    if (csUserId && !iAmTheCsAccount && chat.cs_mode === "ai" && cleanText) {
      if (cleanText.trim() === "1") {
        db.prepare("UPDATE chats SET cs_mode = 'human' WHERE id = ?").run(chat_id);
        await sendSystemChatMessage(
          chat_id,
          csUserId,
          "Oke, kamu sekarang terhubung dengan tim CS manusia kami. Mohon tunggu balasan ya.",
          { isAi: true }
        );
      } else {
        const lastTrigger = lastAiTriggerAt.get(chat_id) || 0;
        if (Date.now() - lastTrigger >= AI_COOLDOWN_MS) {
          lastAiTriggerAt.set(chat_id, Date.now());
          askCsAi(cleanText)
            .then((reply) => sendSystemChatMessage(chat_id, csUserId, reply, { isAi: true }))
            .catch((err) => console.error("[chat] Gagal membalas via AI CS:", err));
        }
      }
    }

    res.json({ message: "Notifikasi terkirim." });
  } catch (err) {
    next(err);
  }
});

export default router;
