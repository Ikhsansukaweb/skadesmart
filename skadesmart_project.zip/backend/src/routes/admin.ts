import { Router } from "express";
import { db } from "../db";
import { authMiddleware } from "../middleware/authMiddleware";
import { requireRole } from "../middleware/roleMiddleware";
import { validate } from "../middleware/validate";
import { defaultLimiter, readLimiter } from "../middleware/rateLimiter";
import { updateUserRoleSchema, updateAppConfigSchema } from "../validators/adminValidator";
import { invalidateByPrefix } from "../services/cache";

const router = Router();

// Semua endpoint di bawah wajib JWT valid dengan role admin (bagian 9).
router.use(authMiddleware, requireRole(["admin"]));

router.get("/users", readLimiter, (req, res) => {
  const users = db
    .prepare("SELECT id, nisn, full_name, class_name, role, created_at FROM users ORDER BY created_at DESC")
    .all();
  res.json({ users });
});

router.put("/users/:id/role", defaultLimiter, validate(updateUserRoleSchema), (req, res) => {
  const id = Number(req.params.id);
  db.prepare("UPDATE users SET role = ?, updated_at = datetime('now') WHERE id = ?").run(req.body.role, id);
  res.json({ message: "Role user diperbarui." });
});

router.delete("/users/:id", defaultLimiter, (req, res) => {
  const id = Number(req.params.id);
  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  res.json({ message: "User dihapus." });
});

router.get("/transactions", readLimiter, (req, res) => {
  const orders = db
    .prepare(
      `SELECT o.*, ub.full_name AS buyer_name, us.full_name AS seller_name
       FROM orders o
       JOIN users ub ON ub.id = o.buyer_id
       JOIN users us ON us.id = o.seller_id
       ORDER BY o.created_at DESC LIMIT 200`
    )
    .all();
  res.json({ orders });
});

router.get("/dashboard/summary", readLimiter, (req, res) => {
  const totalUsers = (db.prepare("SELECT COUNT(*) AS c FROM users").get() as any).c;
  const totalProducts = (db.prepare("SELECT COUNT(*) AS c FROM products WHERE is_active = 1").get() as any).c;
  const totalOrders = (db.prepare("SELECT COUNT(*) AS c FROM orders").get() as any).c;
  const pendingOrders = (
    db.prepare("SELECT COUNT(*) AS c FROM orders WHERE status IN ('baru','diproses','diantar','dicuci')").get() as any
  ).c;
  const revenue = (
    db.prepare("SELECT COALESCE(SUM(total_price),0) AS s FROM orders WHERE status = 'selesai'").get() as any
  ).s;

  res.json({ totalUsers, totalProducts, totalOrders, pendingOrders, revenue });
});

router.put("/app-config", defaultLimiter, validate(updateAppConfigSchema), (req, res) => {
  const fields = req.body;
  const upsert = db.prepare(
    `INSERT INTO app_config (key, value, updated_at) VALUES (?, ?, datetime('now'))
     ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
  );
  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined) continue;
    upsert.run(key, String(value));
  }
  res.json({ message: "Konfigurasi aplikasi diperbarui." });
});

export default router;
