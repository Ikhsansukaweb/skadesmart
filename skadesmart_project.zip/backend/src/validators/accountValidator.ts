import { z } from "zod";

// NISN, nama, dan kelas TIDAK BOLEH diubah siswa sendiri - data ini sudah
// terhubung ke data resmi sekolah per-NISN. Yang boleh diubah cuma foto
// profil, banner, dan preferensi notifikasi.
export const updateProfileSchema = z.object({
  profile_photo_url: z.string().url().optional(),
  banner_url: z.string().url().optional(),
  notif_enabled: z.boolean().optional(),
}).strict();

export const changePasswordSchema = z.object({
  current_password: z.string().min(1),
  new_password: z.string().min(4).max(100),
}).strict();

export const shopStatusSchema = z.object({
  shop_open: z.boolean(),
}).strict();
