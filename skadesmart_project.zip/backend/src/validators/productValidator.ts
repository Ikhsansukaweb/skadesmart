import { z } from "zod";

// Laundry TIDAK punya produk/listing - hanya kwu_brital & jualan bebas siswa.
const categoryEnum = z.enum(["kwu_brital", "siswa"]);

export const createProductSchema = z.object({
  name: z.string().min(3).max(120),
  description: z.string().max(2000).default(""),
  price: z.number().int().positive(),
  stock: z.number().int().min(0),
  category: categoryEnum,
  // Mendukung banyak foto (2,3,4,5+) - foto pertama otomatis jadi sampul.
  image_urls: z.array(z.string().url()).min(1).max(8).optional(),
}).strict();

export const updateProductSchema = z.object({
  name: z.string().min(3).max(120).optional(),
  description: z.string().max(2000).optional(),
  price: z.number().int().positive().optional(),
  stock: z.number().int().min(0).optional(),
  category: categoryEnum.optional(),
  image_urls: z.array(z.string().url()).min(1).max(8).optional(),
  is_active: z.boolean().optional(),
}).strict();

export const listProductsQuerySchema = z.object({
  category: categoryEnum.optional(),
  search: z.string().max(100).optional(),
  seller_id: z.coerce.number().int().positive().optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
}).strict();

export type CreateProductInput = z.infer<typeof createProductSchema>;
