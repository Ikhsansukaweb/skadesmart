import { z } from "zod";

export const createChatSchema = z.object({
  seller_id: z.number().int().positive(),
  product_id: z.number().int().positive().optional(),
}).strict();

// Pesan chat (teks dan/atau foto) ditulis langsung ke Firestore dari client,
// endpoint ini hanya menerima ringkasan untuk update metadata + push notification.
export const notifyChatMessageSchema = z.object({
  chat_id: z.string().min(1),
  text: z.string().max(2000).optional(),
  image_url: z.string().url().optional(),
}).strict().refine((data) => !!data.text || !!data.image_url, {
  message: "Pesan harus berisi teks atau foto.",
});
