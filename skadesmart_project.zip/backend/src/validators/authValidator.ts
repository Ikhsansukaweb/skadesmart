import { z } from "zod";

// Sistem login sementara: NISN wajib 5 digit angka, password bebas/dummy
// (asal tidak kosong) — lihat bagian 3 spesifikasi.
export const loginSchema = z.object({
  nisn: z.string().regex(/^\d{5}$/, "NISN harus berupa 5 digit angka"),
  password: z.string().min(1, "Password wajib diisi"),
}).strict();

// "Registrasi dummy" — nanti diganti data asli dari sekolah.
export const registerSchema = z.object({
  nisn: z.string().regex(/^\d{5}$/, "NISN harus berupa 5 digit angka"),
  password: z.string().min(4, "Password minimal 4 karakter"),
  full_name: z.string().min(1).max(100),
  class_name: z.string().min(1).max(30),
}).strict();

export const fcmTokenSchema = z.object({
  fcm_token: z.string().min(1),
}).strict();

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
