import { z } from "zod";

export const updateUserRoleSchema = z.object({
  role: z.enum(["siswa", "kwu_brital", "kwu_laundry", "cs", "admin"]),
}).strict();

export const updateAppConfigSchema = z.object({
  latest_version: z.string().optional(),
  min_supported_version: z.string().optional(),
  force_update: z.boolean().optional(),
  update_message: z.string().max(300).optional(),
}).strict();

export const moderateContentSchema = z.object({
  is_hidden: z.boolean(),
}).strict();

export const ticketStatusSchema = z.object({
  status: z.enum(["open", "in_progress", "closed"]),
}).strict();
