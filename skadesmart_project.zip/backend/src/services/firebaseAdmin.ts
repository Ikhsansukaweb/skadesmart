import fs from "fs";
import path from "path";
import admin from "firebase-admin";

/**
 * Firebase Admin SDK — dipakai untuk:
 *  1. createCustomToken() saat login (jembatan JWT -> Firestore Rules)
 *  2. messaging().send() untuk push notification (status pesanan & chat baru)
 *  3. Menulis mirror data ke Firestore orders_status/{orderId}
 *
 * Service account JSON TIDAK di-hardcode dan TIDAK di-commit ke repo.
 * Path-nya diambil dari .env: FIREBASE_SERVICE_ACCOUNT_PATH.
 */
let initialized = false;

function initFirebaseAdmin() {
  if (initialized) return;

  const keyPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;
  if (!keyPath) {
    console.warn(
      "[firebaseAdmin] FIREBASE_SERVICE_ACCOUNT_PATH belum diset. " +
      "Fitur Custom Token & push notification akan nonaktif sampai key diisi."
    );
    return;
  }

  const resolvedPath = path.resolve(keyPath);
  if (!fs.existsSync(resolvedPath)) {
    console.warn(
      `[firebaseAdmin] File service account tidak ditemukan di ${resolvedPath}. ` +
      "Generate baru dari Firebase Console > Project Settings > Service Accounts."
    );
    return;
  }

  const serviceAccount = JSON.parse(fs.readFileSync(resolvedPath, "utf-8"));
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: process.env.FIREBASE_PROJECT_ID || "skadesmart",
  });
  initialized = true;
}

initFirebaseAdmin();

export function isFirebaseReady(): boolean {
  return initialized;
}

export async function createFirebaseCustomToken(userId: number): Promise<string | null> {
  if (!initialized) return null;
  return admin.auth().createCustomToken(String(userId));
}

/**
 * Kirim push notification (FCM Web) ke satu device token.
 * Judul & body selalu teks polos, tanpa emoji (aturan desain bagian 7).
 */
export async function sendPushNotification(
  fcmToken: string | null | undefined,
  title: string,
  body: string,
  data: Record<string, string> = {}
): Promise<void> {
  if (!initialized || !fcmToken) return;
  try {
    await admin.messaging().send({
      token: fcmToken,
      notification: { title, body },
      data,
      webpush: {
        fcmOptions: { link: data.link || "/" },
      },
    });
  } catch (err) {
    console.error("[firebaseAdmin] Gagal kirim push notification:", err);
  }
}

/**
 * Mirror status pesanan ke Firestore orders_status/{orderId}.
 * Collection ini read-only dari client (lihat firestore.rules),
 * Admin SDK otomatis bypass Security Rules jadi aman menulis di sini.
 */
export async function mirrorOrderStatus(orderId: number, data: {
  buyerId: number;
  sellerId: number;
  status: string;
  kwuUnit?: string;
}): Promise<void> {
  if (!initialized) return;
  try {
    const db = admin.firestore();
    await db.collection("orders_status").doc(String(orderId)).set(
      {
        buyerId: String(data.buyerId),
        sellerId: String(data.sellerId),
        status: data.status,
        kwuUnit: data.kwuUnit || null,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.error("[firebaseAdmin] Gagal mirror status pesanan ke Firestore:", err);
  }
}

/**
 * Mirror "ada pesanan baru masuk" ke Firestore seller_orders/{sellerId}.
 * Dipakai HANYA untuk pesanan yang diinisiasi SISWA (KWU Brital) - dashboard
 * penjual subscribe ke dokumen ini untuk memutar suara notifikasi otomatis
 * begitu ada pesanan baru, tanpa perlu refresh halaman.
 */
export async function mirrorNewOrder(sellerId: number, orderId: number): Promise<void> {
  if (!initialized) return;
  try {
    const db = admin.firestore();
    await db.collection("seller_orders").doc(String(sellerId)).set(
      {
        lastOrderId: orderId,
        lastOrderAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.error("[firebaseAdmin] Gagal mirror pesanan baru ke Firestore:", err);
  }
}

/**
 * Tulis pesan chat LANGSUNG dari server (Admin SDK, bypass Security Rules) -
 * dipakai balasan bot AI CS dan pesan sistem (mis. "kamu terhubung ke CS
 * manusia"), karena bot tidak punya sesi client seperti user biasa.
 */
export async function sendSystemChatMessage(
  chatId: string,
  senderId: number,
  text: string,
  extra: Record<string, unknown> = {}
): Promise<void> {
  if (!initialized) return;
  try {
    const db = admin.firestore();
    await db.collection("chats").doc(chatId).collection("messages").add({
      senderId: String(senderId),
      text,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      ...extra,
    });
    await mirrorChatMessage(chatId, { lastMessage: text.slice(0, 200), lastSenderId: senderId });
  } catch (err) {
    console.error("[firebaseAdmin] Gagal mengirim pesan sistem ke chat:", err);
  }
}

/**
 * Membuat dokumen chats/{chatId} di Firestore LANGSUNG dari backend (Admin
 * SDK bypass Security Rules), pada saat chat room dibuat di SQLite.
 *
 * Ini memperbaiki race condition lama: sebelumnya dokumen Firestore baru
 * dibuat dari CLIENT setelah pindah ke halaman chat, jadi ada jeda singkat
 * di mana listener pesan (onSnapshot) sudah aktif tapi dokumen induknya
 * belum ada -> Security Rules menolak baca -> chat pertama kali kelihatan
 * kosong sampai halaman dibuka ulang. Dengan dibuat di backend, saat client
 * pindah ke halaman chat dokumennya SUDAH PASTI ada.
 */
export async function createFirestoreChatDoc(
  chatId: string,
  buyerId: number,
  sellerId: number
): Promise<void> {
  if (!initialized) return;
  try {
    const db = admin.firestore();
    await db.collection("chats").doc(chatId).set(
      {
        participants: [String(buyerId), String(sellerId)],
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.error("[firebaseAdmin] Gagal membuat dokumen chat di Firestore:", err);
  }
}

/**
 * Mirror ringkasan pesan terakhir ke Firestore chats/{chatId}, supaya
 * halaman daftar chat di frontend bisa subscribe realtime langsung ke
 * Firestore (bukan cuma polling REST) untuk urutan chat & badge belum dibaca.
 */
export async function mirrorChatMessage(
  chatId: string,
  data: { lastMessage: string; lastSenderId: number }
): Promise<void> {
  if (!initialized) return;
  try {
    const db = admin.firestore();
    await db.collection("chats").doc(chatId).set(
      {
        lastMessage: data.lastMessage,
        lastSenderId: String(data.lastSenderId),
        lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.error("[firebaseAdmin] Gagal mirror pesan chat ke Firestore:", err);
  }
}

export default admin;
