import jwt from "jsonwebtoken";

export type Role = "siswa" | "kwu_brital" | "kwu_laundry" | "cs" | "admin";

export interface JwtPayload {
  user_id: number;
  nisn: string;
  role: Role;
}

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_ganti_ini";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "2d";

export function signToken(payload: JwtPayload): string {
  const options: jwt.SignOptions = {
    algorithm: "HS256",
    expiresIn: JWT_EXPIRES_IN as jwt.SignOptions["expiresIn"],
  };
  return jwt.sign(payload, JWT_SECRET, options);
}

export function verifyToken(token: string): JwtPayload {
  return jwt.verify(token, JWT_SECRET) as JwtPayload;
}

export const AUTH_COOKIE_NAME = "skadesmart_token";
