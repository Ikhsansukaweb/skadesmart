import "dotenv/config";
import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import morgan from "morgan";

import { runMigrations } from "./db";
import { defaultLimiter } from "./middleware/rateLimiter";
import { notFoundHandler, errorHandler } from "./middleware/errorHandler";

import authRoutes from "./routes/auth";
import productRoutes from "./routes/products";
import orderRoutes from "./routes/orders";
import chatRoutes from "./routes/chat";
import ratingRoutes from "./routes/ratings";
import accountRoutes from "./routes/account";
import adminRoutes from "./routes/admin";
import csRoutes from "./routes/cs";
import uploadRoutes from "./routes/upload";
import appRoutes from "./routes/app";
import kwuRoutes from "./routes/kwu";
import cartRoutes from "./routes/cart";
import usersRoutes from "./routes/users";

runMigrations();

const app = express();

// Keamanan dasar: header CSP, X-Content-Type-Options, X-Frame-Options, dst.
app.use(helmet());

// CORS ketat - tidak pakai wildcard, whitelist eksplisit dari .env, credentials
// diaktifkan supaya httpOnly cookie JWT ikut terkirim (bagian 12.2).
app.use(
  cors({
    origin: [process.env.FRONTEND_URL || "http://localhost:3000"],
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

app.use(compression());
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());

// Logging response time per endpoint untuk memantau bottleneck (bagian 8).
morgan.token("body-size", (req, res) => String(res.getHeader("content-length") || 0));
app.use(morgan(":method :url :status :response-time ms - :body-size bytes"));

app.use(defaultLimiter);

app.get("/api/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/chats", chatRoutes);
app.use("/api/ratings", ratingRoutes);
app.use("/api/account", accountRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/cs", csRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/app", appRoutes);
app.use("/api/kwu", kwuRoutes);
app.use("/api/cart", cartRoutes);
app.use("/api/users", usersRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const PORT = Number(process.env.PORT) || 4000;
app.listen(PORT, () => {
  console.log(`SkadesMart backend berjalan di http://localhost:${PORT}`);
});
