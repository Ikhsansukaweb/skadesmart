import "dotenv/config";
import bcrypt from "bcryptjs";
import { db, runMigrations } from "./index";

runMigrations();

// 10 akun dummy lintas role & kelas untuk keperluan testing (bagian akhir
// spesifikasi). Password sama untuk semua: "smkn1" - GANTI di produksi asli
// nanti kalau data NISN sekolah sudah terhubung beneran.
const DUMMY_PASSWORD = "smkn1";

const DUMMY_USERS: { nisn: string; full_name: string; class_name: string; role: string }[] = [
  { nisn: "10001", full_name: "Budi Santoso", class_name: "12RPL1", role: "admin" },
  { nisn: "10002", full_name: "Sari Wulandari", class_name: "11AK1", role: "cs" },
  { nisn: "10003", full_name: "Andi Pratama", class_name: "12BD1", role: "kwu_brital" },
  { nisn: "10004", full_name: "Dewi Anggraini", class_name: "10BR1", role: "kwu_laundry" },
  { nisn: "10005", full_name: "Fajar Ramadhan", class_name: "10AK2", role: "siswa" },
  { nisn: "10006", full_name: "Nadia Putri Ayu", class_name: "11BD1", role: "siswa" },
  { nisn: "10007", full_name: "Rizky Firmansyah", class_name: "12BR2", role: "siswa" },
  { nisn: "10008", full_name: "Intan Permata Sari", class_name: "10RPL1", role: "siswa" },
  { nisn: "10009", full_name: "Bagas Wicaksono", class_name: "11AK3", role: "siswa" },
  { nisn: "10010", full_name: "Citra Ayu Lestari", class_name: "12BD2", role: "siswa" },
];

async function seed() {
  const insert = db.prepare(
    `INSERT INTO users (nisn, password_hash, full_name, class_name, role)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(nisn) DO UPDATE SET
       full_name = excluded.full_name,
       class_name = excluded.class_name,
       role = excluded.role`
  );

  const password_hash = await bcrypt.hash(DUMMY_PASSWORD, 10);

  for (const u of DUMMY_USERS) {
    insert.run(u.nisn, password_hash, u.full_name, u.class_name, u.role);
    console.log(`Seed: ${u.full_name} (${u.nisn}) - ${u.role} - ${u.class_name}`);
  }

  console.log(`\nSelesai. ${DUMMY_USERS.length} akun dummy siap dipakai.`);
  console.log(`Password untuk semua akun dummy: "${DUMMY_PASSWORD}"`);
}

seed().catch((err) => {
  console.error("Gagal seed akun dummy:", err);
  process.exit(1);
});
