-- SkadesMart SQLite schema (v2)
-- Data transaksional utama. Firestore hanya lapisan realtime (chat & mirror status).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nisn          TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name     TEXT NOT NULL,
  class_name    TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'siswa'
                CHECK (role IN ('siswa','kwu_brital','kwu_laundry','cs','admin')),
  profile_photo_url TEXT,
  banner_url    TEXT,
  -- Buka/tutup toko manual (khusus staf kwu_brital/kwu_laundry). Saat tutup,
  -- produk unit itu tidak bisa dipesan dan ditandai "Tutup" di marketplace.
  shop_open     INTEGER NOT NULL DEFAULT 1,
  fcm_token     TEXT,
  notif_enabled INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS kwu_units (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT NOT NULL UNIQUE, -- 'kwu_brital' | 'kwu_laundry'
  name        TEXT NOT NULL,
  description TEXT,
  -- Info cara pesan (dipakai banner "Cara Pesan Laundry" di Home/Marketplace,
  -- karena laundry TIDAK punya listing produk - pemesanan dilakukan langsung
  -- datang ke tempat, bukan lewat marketplace).
  how_to_order TEXT,
  price_info    TEXT,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Produk hanya untuk kwu_brital dan jualan bebas siswa. Laundry sengaja TIDAK
-- punya produk/listing (lihat kwu_units.how_to_order untuk banner info).
CREATE TABLE IF NOT EXISTS products (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category    TEXT NOT NULL CHECK (category IN ('kwu_brital','siswa')),
  name        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price       INTEGER NOT NULL CHECK (price >= 0),
  stock       INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_url   TEXT, -- foto sampul (diambil dari product_images pertama)
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);

-- Galeri foto produk, mendukung banyak foto (2,3,4,5+) sesuai kebutuhan penjual.
CREATE TABLE IF NOT EXISTS product_images (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  image_url   TEXT NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON product_images(product_id);

-- Keranjang belanja untuk unit KWU Brital (checkout multi-produk sekaligus).
CREATE TABLE IF NOT EXISTS cart_items (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity    INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  note        TEXT, -- request khusus siswa untuk item ini (misal: "pedas level 3")
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (user_id, product_id)
);
CREATE INDEX IF NOT EXISTS idx_cart_items_user_id ON cart_items(user_id);

-- Pesanan (order) - dipakai untuk DUA alur berbeda:
--  1) kwu_brital: dibuat SISWA (langsung/dari keranjang), berisi order_items.
--     status: baru -> diproses -> diantar -> selesai (atau dibatalkan)
--  2) kwu_laundry: dibuat STAF kwu_laundry atas nama siswa (siswa datang
--     langsung ke tempat), TIDAK ada order_items (jasa, bukan produk).
--     status: dicuci -> bisa_diambil -> selesai
CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  buyer_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kwu_unit      TEXT NOT NULL CHECK (kwu_unit IN ('kwu_brital','kwu_laundry','siswa')),
  status        TEXT NOT NULL DEFAULT 'baru'
                CHECK (status IN ('baru','diproses','diantar','dicuci','bisa_diambil','selesai','dibatalkan')),
  payment_status TEXT NOT NULL DEFAULT 'belum_bayar' CHECK (payment_status IN ('belum_bayar','sudah_bayar')),
  note          TEXT,          -- brital: request siswa. laundry: catatan staf (misal jenis pakaian).
  quantity      INTEGER,       -- dipakai laundry: jumlah potong pakaian. NULL untuk brital (lihat order_items).
  weight_kg     REAL,          -- dipakai laundry saja
  total_price   INTEGER NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_seller_id ON orders(seller_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer_id ON orders(buyer_id);

-- Item pesanan Brital (snapshot nama & harga saat dipesan, supaya histori
-- tidak berubah walau produk aslinya diedit/dihapus setelahnya).
CREATE TABLE IF NOT EXISTS order_items (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  product_name  TEXT NOT NULL,
  unit_price    INTEGER NOT NULL CHECK (unit_price >= 0),
  quantity      INTEGER NOT NULL CHECK (quantity > 0),
  note          TEXT
);
CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id);

-- Metadata chat saja. Isi pesan (termasuk foto) disimpan realtime di
-- Firestore chats/{chatId}/messages.
CREATE TABLE IF NOT EXISTS chats (
  id            TEXT PRIMARY KEY,      -- dipakai juga sebagai Firestore doc id (chats/{id})
  buyer_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
  last_message  TEXT,
  last_sender_id INTEGER,
  last_message_at TEXT,
  -- Senyapkan notifikasi push per sisi (dipakai menu titik-tiga di chat).
  muted_by_buyer  INTEGER NOT NULL DEFAULT 0,
  muted_by_seller INTEGER NOT NULL DEFAULT 0,
  -- Khusus chat dengan akun CS: 'ai' = dibalas bot otomatis, 'human' = sudah
  -- dieskalasi ke staf CS manusia (siswa ketik "1" untuk pindah ke sini).
  cs_mode         TEXT NOT NULL DEFAULT 'ai' CHECK (cs_mode IN ('ai','human')),
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (buyer_id, seller_id)
);
CREATE INDEX IF NOT EXISTS idx_chats_buyer_id ON chats(buyer_id);
CREATE INDEX IF NOT EXISTS idx_chats_seller_id ON chats(seller_id);

-- Rating terikat ke order (bukan cuma produk), supaya laundry (yang tidak
-- punya produk) tetap bisa dirating. product_id NULL untuk rating laundry.
CREATE TABLE IF NOT EXISTS ratings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  buyer_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  seller_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kwu_unit    TEXT NOT NULL CHECK (kwu_unit IN ('kwu_brital','kwu_laundry','siswa')),
  product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
  score       INTEGER NOT NULL CHECK (score BETWEEN 1 AND 5),
  comment     TEXT,
  is_hidden   INTEGER NOT NULL DEFAULT 0, -- moderasi CS
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (order_id) -- satu pesanan cuma bisa dirating sekali
);
CREATE INDEX IF NOT EXISTS idx_ratings_seller_id ON ratings(seller_id);
CREATE INDEX IF NOT EXISTS idx_ratings_product_id ON ratings(product_id);

CREATE TABLE IF NOT EXISTS app_config (
  key         TEXT PRIMARY KEY,
  value       TEXT NOT NULL,
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cs_tickets (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject     TEXT NOT NULL,
  message     TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','closed')),
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO kwu_units (slug, name, description, how_to_order, price_info) VALUES
  ('kwu_brital', 'Ayam Geprek Brital', 'Unit usaha kuliner ayam geprek SMKN 1 Depok Sleman', NULL, NULL),
  ('kwu_laundry', 'Laundry', 'Unit usaha jasa laundry SMKN 1 Depok Sleman',
   '1. Datang langsung ke tempat laundry sekolah.
2. Serahkan pakaianmu ke petugas KWU Laundry.
3. Petugas akan mencatat data pesananmu ke sistem.
4. Pantau status cucian lewat halaman Status Pesanan di akunmu.
5. Ambil pakaian setelah status berubah menjadi "Bisa Diambil".',
   'Hubungi petugas Laundry langsung di tempat untuk info harga per kg.');

INSERT OR IGNORE INTO app_config (key, value) VALUES
  ('latest_version', '1.0.0'),
  ('min_supported_version', '1.0.0'),
  ('force_update', 'false'),
  ('update_message', 'Versi terbaru tersedia.');
